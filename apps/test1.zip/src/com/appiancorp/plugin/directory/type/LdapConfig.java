package com.appiancorp.plugin.directory.type;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name="LdapConfig", namespace="urn:appian:plugin:directory", propOrder = {
	"scsExternalSystemKey",
	"usePerUserCredentials",
	"url",
	"baseDn",
	"authentication",
	"referral",
	"timeout",
	"type",
	"VLVControlSupported",
	"keystorePath"
})
public class LdapConfig {
	private String scsExternalSystemKey;
	private boolean usePerUserCredentials = false;
	private String url;
	private String baseDn = "";
	private String authentication = "simple";
	private String referral = "follow";
	private int timeout = 1000;
	private String type = "clear";
	private boolean vlvControlSupported = true;
	private String keystorePath;

	@XmlElement
	public String getScsExternalSystemKey() {
		return scsExternalSystemKey;
	}

	@XmlElement
	public boolean getUsePerUserCredentials() {
		return usePerUserCredentials;
	}
	
	@XmlElement
	public String getUrl() {
		return url;
	}
	
	@XmlElement
	public String getBaseDn() {
	    return baseDn;
	}
	
	@XmlElement
	public String getAuthentication() {
		return authentication;
	}
	
	@XmlElement
	public String getReferral() {
		return referral;
	}
	
	@XmlElement
	public int getTimeout() {
		return timeout;
	}

	@XmlElement
	public String getType() {
		return type;
	}

	@XmlElement
	public boolean getVLVControlSupported() {
		return vlvControlSupported;
	}
	
	@XmlElement
	public String getKeystorePath() {
	    return keystorePath;
	}

	public void setScsExternalSystemKey(String scsExternalSystemKey) {
		this.scsExternalSystemKey = scsExternalSystemKey;
	}

	public void setUsePerUserCredentials(boolean usePerUserCredentials) {
		this.usePerUserCredentials = usePerUserCredentials;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	public void setBaseDn(String baseDn) {
	    this.baseDn = baseDn;
	}

	public void setAuthentication(String authentication) {
		this.authentication = authentication;
	}

	public void setReferral(String referral) {
		this.referral = referral;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setVLVControlSupported(boolean vlvControlSupported) {
		this.vlvControlSupported = vlvControlSupported;
	}
	
	public void setKeystorePath(String keystorePath) {
        this.keystorePath = keystorePath;
    }
}
