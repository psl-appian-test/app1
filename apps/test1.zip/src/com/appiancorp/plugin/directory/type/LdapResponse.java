package com.appiancorp.plugin.directory.type;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.appiancorp.suiteapi.common.paging.TypedValueDataSubset;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name="LdapResponse", namespace="urn:appian:plugin:directory", propOrder = {
	"success",
	"result",
	"error"
})
public class LdapResponse {
	private boolean success;
	private TypedValueDataSubset result;
	private String error;

	public LdapResponse() { }

	public LdapResponse(boolean success, TypedValueDataSubset result, String error) {
		this.success = success;
		this.result = result;
		this.error = error;
	}

	@XmlElement
	public boolean isSuccess() {
		return success;
	}

	@XmlElement
	public TypedValueDataSubset getResult() {
		return result;
	}

	@XmlElement
	public String getError() {
		return error;
	}
}
