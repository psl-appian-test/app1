package com.appiancorp.plugin.directory.type;

public class LdapSyncConfig {
	private String connectionKeystore;
	private String connectionKeystorePassword;
	private String connectionReferral;
	private String connectionType;
	private Boolean connectionUsepool;
	private String connectionUrl;
	private Long connectionTimeout;
	private String scsExternalSystemKey;
	private boolean usePerUserCredentials;
	private String authenticationBaseDN;
	private String authenticationType;
	private String authenticationUserPrefix;
	private String authenticationUserSuffix;
	private String authenticationUserName;
	private String authenticationUserPassword;
	private String synchUserFilter;
	private String synchUserDeactivatedBaseDN;
	private String synchUserDeactivatedFilter;
	private Boolean synchUserReactivate;
	private Boolean synchLowercaseUsername;
	private Boolean pageControlSupported;
	private Long pageControlPageSize;
	private String userAddressCity;
	private String userAddressCountry;
	private String userAddressLine1;
	private String userAddressLine2;
	private String userAddressLine3;
	private String userAddressPostalCode;
	private String userAddressProvince;
	private String userAddressState;
	private String userCustom1;
	private String userCustom2;
	private String userCustom3;
	private String userCustom4;
	private String userCustom5;
	private String userCustom6;
	private String userCustom7;
	private String userCustom8;
	private String userCustom9;
	private String userCustom10;
	private String userEmail;
	private String userDisplayName;
	private String userFirstName;
	private String userLastName;
	private String userMiddleName;
	private String userPhoneHome;
	private String userPhoneMobile;
	private String userPhoneOffice;
	private String userSupervisorUsername;
	private String userTitle;
	private String userProfilePhoto;
	private String userUsername;

	public void setConnectionKeystore(String val) {
		this.connectionKeystore = val;
	}
	
	public void setConnectionKeystorePassword(String val) {
	    this.connectionKeystorePassword = val;
	}

	public void setConnectionReferral(String val) {
		this.connectionReferral = val;
	}

	public void setConnectionType(String val) {
		this.connectionType = val;
	}

	public void setConnectionUsepool(Boolean val) {
		this.connectionUsepool = val;
	}

	public void setConnectionUrl(String val) {
		this.connectionUrl = val;
	}

	public void setConnectionTimeout(Long val) {
		this.connectionTimeout = val;
	}

	public void setScsExternalSystemKey(String val) {
		this.scsExternalSystemKey = val;
	}

	public void setUsePerUserCredentials(Boolean val) {
		this.usePerUserCredentials = val;
	}

	public void setAuthenticationBaseDN(String val) {
		this.authenticationBaseDN = val;
	}

	public void setAuthenticationType(String val) {
		this.authenticationType = val;
	}

	public void setAuthenticationUserPrefix(String val) {
		this.authenticationUserPrefix = val;
	}

	public void setAuthenticationUserSuffix(String val) {
		this.authenticationUserSuffix = val;
	}

	public void setAuthenticationUserName(String val) {
		this.authenticationUserName = val;
	}

	public void setAuthenticationUserPassword(String val) {
		this.authenticationUserPassword = val;
	}

	public void setSynchUserFilter(String val) {
		this.synchUserFilter = val;
	}

	public void setSynchUserDeactivatedBaseDN(String val) {
		this.synchUserDeactivatedBaseDN = val;
	}

	public void setSynchUserDeactivatedFilter(String val) {
		this.synchUserDeactivatedFilter = val;
	}

	public void setSynchUserReactivate(Boolean val) {
		this.synchUserReactivate = val;
	}

	public void setSynchLowercaseUsername(Boolean val) {
		this.synchLowercaseUsername = val;
	}

	public void setUserAddressCity(String val) {
		this.userAddressCity = val;
	}

	public void setUserAddressCountry(String val) {
		this.userAddressCountry = val;
	}

	public void setUserAddressLine1(String val) {
		this.userAddressLine1 = val;
	}

	public void setUserAddressLine2(String val) {
		this.userAddressLine2 = val;
	}

	public void setUserAddressLine3(String val) {
		this.userAddressLine3 = val;
	}

	public void setUserAddressPostalCode(String val) {
		this.userAddressPostalCode = val;
	}

	public void setUserAddressProvince(String val) {
		this.userAddressProvince = val;
	}

	public void setUserAddressState(String val) {
		this.userAddressState = val;
	}

	public void setUserCustom1(String val) {
		this.userCustom1 = val;
	}

	public void setUserCustom2(String val) {
		this.userCustom2 = val;
	}

	public void setUserCustom3(String val) {
		this.userCustom3 = val;
	}

	public void setUserCustom4(String val) {
		this.userCustom4 = val;
	}

	public void setUserCustom5(String val) {
		this.userCustom5 = val;
	}

	public void setUserCustom6(String val) {
		this.userCustom6 = val;
	}

	public void setUserCustom7(String val) {
		this.userCustom7 = val;
	}

	public void setUserCustom8(String val) {
		this.userCustom8 = val;
	}

	public void setUserCustom9(String val) {
		this.userCustom9 = val;
	}

	public void setUserCustom10(String val) {
		this.userCustom10 = val;
	}

	public void setUserEmail(String val) {
		this.userEmail = val;
	}

	public void setUserDisplayName(String val) {
		this.userDisplayName = val;
	}

	public void setUserFirstName(String val) {
		this.userFirstName = val;
	}

	public void setUserLastName(String val) {
		this.userLastName = val;
	}

	public void setUserMiddleName(String val) {
		this.userMiddleName = val;
	}

	public void setUserPhoneHome(String val) {
		this.userPhoneHome = val;
	}

	public void setUserPhoneMobile(String val) {
		this.userPhoneMobile = val;
	}

	public void setUserPhoneOffice(String val) {
		this.userPhoneOffice = val;
	}

	public void setUserSupervisorUsername(String val) {
		this.userSupervisorUsername = val;
	}

	public void setUserTitle(String val) {
		this.userTitle = val;
	}

	public void setUserProfilePhoto(String val) {
		this.userProfilePhoto = val;
	}

	public void setUserUsername(String val) {
		this.userUsername = val;
	}

	public void setPageControlSupported(Boolean val) {
		this.pageControlSupported = val;
	}

	public void setPageControlPageSize(Long val) {
		this.pageControlPageSize = val;
	}

	public String getConnectionKeystore() {
		return connectionKeystore;
	}
	
	public String getConnectionKeystorePassword() {
      return connectionKeystorePassword;
    }

	public String getConnectionReferral() {
		return connectionReferral;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public Boolean getConnectionUsepool() {
		return connectionUsepool;
	}

	public String getUserAddressState() {
		return userAddressState;
	}

	public String getConnectionUrl() {
		return connectionUrl;
	}

	public Long getConnectionTimeout() {
		return connectionTimeout;
	}

	public String getScsExternalSystemKey() {
		return scsExternalSystemKey;
	}

	public boolean getUsePerUserCredentials() {
		return usePerUserCredentials;
	}
	
	public String getAuthenticationBaseDN() {
		return authenticationBaseDN;
	}

	public String getAuthenticationType() {
		return authenticationType;
	}

	public String getAuthenticationUserPrefix() {
		return authenticationUserPrefix;
	}

	public String getAuthenticationUserSuffix() {
		return authenticationUserSuffix;
	}

	public String getAuthenticationUserName() {
		return authenticationUserName;
	}

	public String getAuthenticationUserPassword() {
		return authenticationUserPassword;
	}

	public String getSynchUserFilter() {
		return synchUserFilter;
	}

	public String getSynchUserDeactivatedBaseDN() {
		return synchUserDeactivatedBaseDN;
	}

	public String getSynchUserDeactivatedFilter() {
		return synchUserDeactivatedFilter;
	}

	public Boolean getSynchUserReactivate() {
		return synchUserReactivate;
	}

	public Boolean getSynchLowercaseUsername() {
		return synchLowercaseUsername;
	}

	public String getUserAddressCity() {
		return userAddressCity;
	}

	public String getUserAddressCountry() {
		return userAddressCountry;
	}

	public String getUserAddressLine1() {
		return userAddressLine1;
	}

	public String getUserAddressLine2() {
		return userAddressLine2;
	}

	public String getUserAddressLine3() {
		return userAddressLine3;
	}

	public String getUserAddressPostalCode() {
		return userAddressPostalCode;
	}

	public String getUserAddressProvince() {
		return userAddressProvince;
	}

	public String getUserCustom1() {
		return userCustom1;
	}

	public String getUserCustom2() {
		return userCustom2;
	}

	public String getUserCustom3() {
		return userCustom3;
	}

	public String getUserCustom4() {
		return userCustom4;
	}

	public String getUserCustom5() {
		return userCustom5;
	}

	public String getUserCustom6() {
		return userCustom6;
	}

	public String getUserCustom7() {
		return userCustom7;
	}

	public String getUserCustom8() {
		return userCustom8;
	}

	public String getUserCustom9() {
		return userCustom9;
	}

	public String getUserCustom10() {
		return userCustom10;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public String getUserDisplayName() {
		return userDisplayName;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public String getUserMiddleName() {
		return userMiddleName;
	}

	public String getUserPhoneHome() {
		return userPhoneHome;
	}

	public String getUserPhoneMobile() {
		return userPhoneMobile;
	}

	public String getUserPhoneOffice() {
		return userPhoneOffice;
	}

	public String getUserSupervisorUsername() {
		return userSupervisorUsername;
	}

	public String getUserTitle() {
		return userTitle;
	}

	public String getUserUsername() {
		return userUsername;
	}

	public Boolean getPageControlSupported() {
		return pageControlSupported;
	}

	public Long getPageControlPageSize() {
		return pageControlPageSize;
	}

	public String getUserProfilePhoto() {
		return userProfilePhoto;
	}
}
