package com.appiancorp.plugin.directory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.ldaptive.BindRequest;
import org.ldaptive.Connection;
import org.ldaptive.ConnectionConfig;
import org.ldaptive.Credential;
import org.ldaptive.DefaultConnectionFactory;
import org.ldaptive.LdapAttribute;
import org.ldaptive.LdapEntry;
import org.ldaptive.Response;
import org.ldaptive.SearchOperation;
import org.ldaptive.SearchRequest;
import org.ldaptive.SearchResult;
import org.ldaptive.control.PagedResultsControl;
import org.ldaptive.control.ResponseControl;
import org.ldaptive.control.SortKey;
import org.ldaptive.control.SortRequestControl;
import org.ldaptive.control.VirtualListViewResponseControl;
import org.ldaptive.control.util.VirtualListViewClient;
import org.ldaptive.control.util.VirtualListViewParams;
import org.ldaptive.ssl.KeyStoreCredentialConfig;
import org.ldaptive.ssl.SslConfig;

import com.appiancorp.plugin.directory.type.LdapConfig;
import com.appiancorp.plugin.directory.type.LdapResponse;
import com.appiancorp.suiteapi.common.paging.PagingInfo;
import com.appiancorp.suiteapi.common.paging.SortInfo;
import com.appiancorp.suiteapi.common.paging.TypedValueDataSubset;
import com.appiancorp.suiteapi.expression.annotations.AppianScriptingFunctionsCategory;
import com.appiancorp.suiteapi.expression.annotations.Function;
import com.appiancorp.suiteapi.expression.annotations.Parameter;
import com.appiancorp.suiteapi.security.external.SecureCredentialsStore;
import com.appiancorp.suiteapi.type.AppianType;
import com.appiancorp.suiteapi.type.TypedValue;

@AppianScriptingFunctionsCategory
public class LdapFunctions {
	private static final Logger LOG = Logger.getLogger(LdapFunctions.class);
	private static final String CRED_USERNAME = "username";
	private static final String CRED_PASSWORD = "password";

	@Function
	public LdapResponse ldapSearch(
		SecureCredentialsStore scs,
		@Parameter LdapConfig config,
		@Parameter String searchFilter,
		@Parameter(required = false) String[] attributes,
		@Parameter(required = false) PagingInfo pagingInfo
	) {
		BindRequest bind = null;

		// Use anonymous binding if SCS key is not set
		if (StringUtils.isNotEmpty(config.getScsExternalSystemKey())) {
			try {
				Map<String, String> credentials = config.getUsePerUserCredentials() ? scs.getUserSecuredValues(config.getScsExternalSystemKey()) : scs.getSystemSecuredValues(config.getScsExternalSystemKey());

				if (!credentials.containsKey(CRED_USERNAME)) {
					return new LdapResponse(false, null, String.format("Required field %s does not exist in SCS (%s)", CRED_USERNAME, config.getScsExternalSystemKey()));
				} else if (!credentials.containsKey(CRED_PASSWORD)) {
					return new LdapResponse(false, null, String.format("Required field %s does not exist in SCS (%s)", CRED_PASSWORD, config.getScsExternalSystemKey()));
				}

				bind = new BindRequest(credentials.get(CRED_USERNAME), new Credential(credentials.get(CRED_PASSWORD)));
			} catch (Exception e) {
				LOG.error("Unable to retrieve credentials from SCS", e);
				return new LdapResponse(false, null, String.format("Unable to retrieve credentials from SCS: %s", e.getMessage()));
			}
		}
        
		ConnectionConfig connConfig = new ConnectionConfig(config.getUrl());
		SearchRequest request = new SearchRequest(config.getBaseDn(), searchFilter, attributes);

		connConfig.setConnectTimeout(config.getTimeout());
		connConfig.setResponseTimeout(config.getTimeout());
	
		// Set SSL Configurations
        if (config.getType().equals("ssl")) {
          connConfig.setUseSSL(true);
          if (!config.getKeystorePath().isEmpty()) {
            KeyStoreCredentialConfig credConfig = new KeyStoreCredentialConfig();
            credConfig.setTrustStore("file:" + config.getKeystorePath());
            connConfig.setSslConfig(new SslConfig(credConfig));
          }
        }
        
        Connection conn;
        try {
          conn = DefaultConnectionFactory.getConnection(connConfig);
        } catch (Exception e) {
          LOG.error("Error initializing connection", e);
          return new LdapResponse(false, null, String.format("Error initializing connection: %s", e.getMessage()));
        }
		SortKey[] sort;

		if (pagingInfo == null) {
			pagingInfo = new PagingInfo(1, 10);
		}

		if (pagingInfo.getSort() != null && pagingInfo.getSort().size() > 0) {
			List<SortKey> sortList = new ArrayList<SortKey>();

			for (SortInfo sortInfo : pagingInfo.getSort()) {
				sortList.add(new SortKey(sortInfo.getField(), null, sortInfo.isAscending()));
			}

			sort = sortList.toArray(new SortKey[] {}); // for VirtualListView
			request.setControls(new SortRequestControl(sort, true)); // for SearchOperation
		} else {
			// default sort needed for VirtualListView
			sort = new SortKey[] { new SortKey("mail") };
		}

		try {
			if (bind == null) {
				conn.open();
			} else {
				conn.open(bind);
			}
		} catch (Exception e) {
			LOG.error("Unable to bind to LDAP server", e);
			return new LdapResponse(false, null, String.format("Unable to bind to LDAP server: %s", getExceptionMessage(e)));
		}

		List<TypedValue> dataList = new ArrayList<>();
		List<TypedValue> identifiers = new ArrayList<>();
		int totalCount;

		try {
			Response<SearchResult> response;

			try {
				if (config.getVLVControlSupported()) {
					VirtualListViewClient client = new VirtualListViewClient(conn, sort);
					response = client.execute(request, new VirtualListViewParams(pagingInfo.getStartIndex(), 0, pagingInfo.getBatchSize() - 1));
				} else {
					if (pagingInfo.getBatchSize() > 0) {
						request.setSizeLimit(pagingInfo.getBatchSize());
					}

					SearchOperation search = new SearchOperation(conn);
					response = search.execute(request);
				}
			} catch (Exception e) {
				LOG.error("Failed to request page", e);
				return new LdapResponse(false, null, String.format("Failed to request page: %s", getExceptionMessage(e)));
			}

			// Process the results
			for (LdapEntry entry : response.getResult().getEntries()) {
				TypedValue dictionary = new TypedValue((long) AppianType.DICTIONARY);
				Map<TypedValue, TypedValue> dictionaryMap = new HashMap<TypedValue, TypedValue>();

				for (LdapAttribute attr : entry.getAttributes()) {
					if (attr.isBinary()) {
						LOG.info("Ignoring binary attribute: " + attr.getName());
						continue;
					}
					
					if (attributes.length > 0 && !Arrays.asList(attributes).contains(attr.getName())) {
					   LOG.info("Ignoring attribute not part of original request (prevent case insensitive attribute searches): " + attr.getName());
                       continue;
					}

					TypedValue key = new TypedValue((long) AppianType.STRING, attr.getName());
					TypedValue value;

					if (attr.size() > 1) {
						value = new TypedValue((long) AppianType.LIST_OF_STRING, attr.getStringValues().toArray(new String[] {}));
					} else {
						value = new TypedValue((long) AppianType.STRING, attr.getStringValue());
					}

					dictionaryMap.put(key, value);
				}

				dictionary.setValue(dictionaryMap);
				dataList.add(dictionary);
				identifiers.add(new TypedValue((long) AppianType.STRING, entry.getDn()));
			}

			// Process the response controls
			totalCount = dataList.size();

			if (response.getControls() != null) {
				for (ResponseControl control : response.getControls()) {
					if (control instanceof VirtualListViewResponseControl) {
						VirtualListViewResponseControl vlvrc = (VirtualListViewResponseControl) control;
						totalCount = vlvrc.getContentCount();
					} else if (control instanceof PagedResultsControl) {
						PagedResultsControl prc = (PagedResultsControl) control;
						totalCount = prc.getSize();
					}
				}
			}
		} finally {
			conn.close();
		}

		return new LdapResponse(
			true, // success
			new TypedValueDataSubset(
				pagingInfo.getStartIndex(),
				pagingInfo.getBatchSize(),
				pagingInfo.getSort(),
				totalCount,
				dataList,
				identifiers
			),
			null // no error
		);
	}

	// Removes 0x0 character that MS-AD returns in exceptions that causes XML conversion error (APNX-1-4198-000) in Appian
	private String getExceptionMessage(Exception e) {
		return (e.getMessage() == null) ? null : e.getMessage().replace((char) 0, ' ');
	}
}
