package com.appiancorp.plugins.github.smartservices;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.eclipse.egit.github.core.Repository;
import org.eclipse.egit.github.core.service.RepositoryService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.INTEGRATION_SERVICES, palette=AbstractGithubSmartService.GITHUB_SERVICES)
public class CreateRepository extends AbstractGithubSmartService {
	private static final Logger LOG = Logger.getLogger(CreateRepository.class);
	
	private String name;
	private String organization;
	private String description;
	private String homepageURL;
	private String visibility;
		
	private String repositoryName;
	
	@Override
	public void run() throws SmartServiceException {
		RepositoryService service = super.createRepositoryService();
		
		Repository repo = new Repository();
		repo.setName(name).setDescription(description).setHomepage(homepageURL).setPrivate(visibility.equals(PRIVATE));
		
		if(StringUtils.isBlank(organization)) {
			try {
				repo = service.createRepository(repo);
			} catch (IOException e) {
				throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
			}
		} else {
			try {
				repo = service.createRepository(organization, repo);
			} catch (IOException e) {
				throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
			}
		}
		
		repositoryName = repo.getName();
	}

	public String getRepositoryName() {
		return repositoryName;
	}

	@Input(required=Required.ALWAYS)
	public void setName(String name) {
		this.name = name;
	}

	@Input(required=Required.OPTIONAL)
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	@Input(required=Required.OPTIONAL)
	public void setDescription(String description) {
		this.description = description;
	}

	@Input(required=Required.OPTIONAL)
	public void setHomepageURL(String homepageURL) {
		this.homepageURL = homepageURL;
	}

	@Input(enumeration = "Visibility", required=Required.OPTIONAL)
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
}
