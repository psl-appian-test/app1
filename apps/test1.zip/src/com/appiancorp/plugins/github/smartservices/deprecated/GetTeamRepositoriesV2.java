package com.appiancorp.plugins.github.smartservices.deprecated;

import java.util.List;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.schema.Repository;
import com.github.api.v2.services.OrganizationService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class GetTeamRepositoriesV2 extends GithubSmartServiceV2 {
	private String teamID;
	
	private String[] repositoryNames;
	
	@Override
	public void run() throws SmartServiceException {
		OrganizationService service = getOrganizationService();
		
		List<Repository> repositories = service.getTeamRepositories(teamID);
		
		repositoryNames = new String[repositories.size()];
		
		int i = 0;
		
		for(Repository repository : repositories) {
			repositoryNames[i] = repository.getName();
			i++;
		}
	}

	public String[] getRepositoryNames() {
		return repositoryNames;
	}

	public void setTeamID(String teamID) {
		this.teamID = teamID;
	}
}
