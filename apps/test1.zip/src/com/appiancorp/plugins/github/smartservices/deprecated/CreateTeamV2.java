package com.appiancorp.plugins.github.smartservices.deprecated;

import java.util.ArrayList;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.schema.Permission;
import com.github.api.v2.schema.Team;
import com.github.api.v2.services.OrganizationService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class CreateTeamV2 extends GithubSmartServiceV2 {

	private String organizationName;
	private String teamName;
	private String permission;
		
	private String teamId;
	
	@Override
	public void run() throws SmartServiceException {
		OrganizationService service = getOrganizationService();
				
		//Passing null for repo parameter throws NullPointerException so just pass empty list
		Team newTeam = service.createTeam(organizationName, teamName, Permission.fromValue(permission), new ArrayList<String>());
		teamId = newTeam.getId();
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	@Input(enumeration = "Permission")
	public void setPermission(String permission) {
		this.permission = permission;
	}

	public String getTeamId() {
		return teamId;
	}

}
