package com.appiancorp.plugins.github.smartservices.deprecated;

import java.util.ArrayList;
import java.util.List;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.schema.Repository;
import com.github.api.v2.services.GitHubException;
import com.github.api.v2.services.GitHubServiceFactory;
import com.github.api.v2.services.OrganizationService;
import com.github.api.v2.services.RepositoryService;
import com.github.api.v2.services.auth.Authentication;
import com.github.api.v2.services.auth.LoginTokenAuthentication;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class GetForksV2 extends GithubSmartServiceV2 {
	private String repositoryName;
	private String[] forkOwners;
	
	public void setRepositoryName(String repositoryName) {
	  this.repositoryName = repositoryName;
	}
	
	public String[] getForkOwners() {
	  return forkOwners;
	}
	
	/*
	 * Only works when username has forked repositoryName,
	 * for some reason using another username other than
	 * the logged-in returns an empty network (forks)
	 */
	private String[] getForks1(RepositoryService reposvc, String username, String repositoryName) {
	  List<Repository> forks = reposvc.getForks(username, repositoryName);
	  List<String> owners = new ArrayList<String>(forks.size());
	  for(Repository r : forks) {
	    owners.add(r.getOwner());
	  }
	  String[] forkOwners = owners.toArray(new String[owners.size()]);
	  return forkOwners;
	}
	
	/*
	 * Indirect way of getting forks: traverse all repositories
	 * within the organization and find the ones with the same name
	 */
	private String[] getForks2(OrganizationService orgsvc, String repositoryName) {
	  List<Repository> allRepos = orgsvc.getAllOrganizationRepositories();
	  List<String> forkOwners = new ArrayList<String>(allRepos.size());
	  for(Repository r : allRepos) {
	    if(repositoryName.equals(r.getName())) {
	      forkOwners.add(r.getOwner());
	    }
	  }
	  return forkOwners.toArray(new String[forkOwners.size()]);
	}
	
	public String[] getForks(GitHubServiceFactory factory, Authentication auth, String username, String repositoryName) {
	  RepositoryService reposvc = factory.createRepositoryService();
	  reposvc.setAuthentication(auth);
	  String[] forkOwners;
	  try {
	    forkOwners = getForks1(reposvc, username, repositoryName);
	  } catch(GitHubException e) {
	    OrganizationService orgsvc = factory.createOrganizationService();
	    orgsvc.setAuthentication(auth);
	    forkOwners = getForks2(orgsvc, repositoryName);
	  }
	  return forkOwners;
	}
	
	@Override
	public void run() throws SmartServiceException {
	  GitHubServiceFactory factory = GitHubServiceFactory.newInstance();
	  Authentication auth = new LoginTokenAuthentication(username, apiToken);
	  forkOwners = getForks(factory, auth, username, repositoryName);
	}
}
