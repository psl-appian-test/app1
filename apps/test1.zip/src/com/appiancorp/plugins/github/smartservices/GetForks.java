package com.appiancorp.plugins.github.smartservices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.egit.github.core.Repository;
import org.eclipse.egit.github.core.RepositoryId;
import org.eclipse.egit.github.core.service.RepositoryService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;

@PaletteInfo(paletteCategory = PaletteCategoryConstants.INTEGRATION_SERVICES, palette = AbstractGithubSmartService.GITHUB_SERVICES)
public class GetForks extends AbstractGithubSmartService {
	private String repositoryOwner;
	private String repositoryName;
	private String[] forkOwners;

	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	public String[] getForkOwners() {
		return forkOwners;
	}

	public String[] getForks(String owner, String repositoryName)
			throws IOException {
		RepositoryService service = super.createRepositoryService();

		List<Repository> forks = service.getForks(new RepositoryId(owner,
				repositoryName));

		List<String> forkOwners = new ArrayList<String>(forks.size());

		for (Repository fork : forks) {
			forkOwners.add(fork.getOwner().getLogin());
		}

		return forkOwners.toArray(new String[forkOwners.size()]);
	}

	@Override
	public void run() throws SmartServiceException {
		try {
			forkOwners = getForks(repositoryOwner, repositoryName);
		} catch (IOException e) {
			throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
		}
	}
}
