package com.appiancorp.plugins.github.smartservices;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.eclipse.egit.github.core.RepositoryId;
import org.eclipse.egit.github.core.service.TeamService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.INTEGRATION_SERVICES, palette=AbstractGithubSmartService.GITHUB_SERVICES)
public class AddTeamRepository extends AbstractGithubSmartService {
	private static final Logger LOG = Logger.getLogger(AddTeamRepository.class);
	
	private int teamId;
	private String repositoryOwner;
	private String repositoryName;
		
	@Override
	public void run() throws SmartServiceException {
		TeamService service = super.createTeamService();
		RepositoryId repo = new RepositoryId(repositoryOwner, repositoryName);
		
		try {
			if(LOG.isDebugEnabled()) {
				LOG.debug("Adding team " + teamId + " to repository " + repo.toString() + "...");
			}
			
			service.addRepository(teamId, repo);
		} catch (IOException e) {
			throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
		}
	}

	@Input(required=Required.ALWAYS)
	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	@Input(required=Required.ALWAYS)
	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}
	
	@Input(required=Required.ALWAYS)
	public void setRepositoryOwner(String repositoryOwner) {
		this.repositoryOwner = repositoryOwner;
	}
}
