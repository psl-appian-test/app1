package com.appiancorp.plugins.github.smartservices.deprecated;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.services.OrganizationService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class AddTeamRepositoryV2 extends GithubSmartServiceV2 {
	private String teamId;
	private String repositoryName;
		
	@Override
	public void run() throws SmartServiceException {
		OrganizationService service = getOrganizationService();
		
		service.addTeamRepository(teamId, repositoryName);
	}


	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}


	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}
}
