package com.appiancorp.plugins.github.smartservices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicReference;

import org.eclipse.egit.github.core.RepositoryBranch;
import org.eclipse.egit.github.core.RepositoryId;
import org.eclipse.egit.github.core.service.RepositoryService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;

@PaletteInfo(paletteCategory = PaletteCategoryConstants.INTEGRATION_SERVICES, palette = AbstractGithubSmartService.GITHUB_SERVICES)
public class GetBranches extends AbstractGithubSmartService {
	private String repositoryName, repositoryOwner;
	private String[] fork, branch, revision, refspec;
	private static final AtomicReference<Set<Branch>> cache = new AtomicReference<Set<Branch>>();

	public void setRepositoryName(String repositoryName) {
		this.repositoryName = repositoryName;
	}

	public void setRepositoryOwner(String repositoryOwner) {
		this.repositoryOwner = repositoryOwner;
	}

	public String[] getFork() {
		return fork;
	}

	public String[] getBranch() {
		return branch;
	}

	public String[] getRevision() {
		return revision;
	}

	public String[] getRefspec() {
		return refspec;
	}

	private static class Branch implements Comparable<Branch> {
		private String fork;
		private String branch;
		private String revision;
		private static String first;

		public Branch(String fork, String branch, String revision) {
			this.fork = fork;
			this.branch = branch;
			this.revision = revision;
		}

		public static void setFirst(String first) {
			Branch.first = first;
		}

		public String getFork() {
			return fork;
		}

		public String getBranch() {
			return branch;
		}

		public String getRevision() {
			return revision;
		}

		public String getKey() {
			return String.format("%s/%s/%s", fork, branch, revision);
		}

		@Override
		public int compareTo(Branch o) {
			if (getFork().equals(o.getFork())) {
				return getKey().compareTo(o.getKey());
			}
			if (first != null) {
				if (o.getFork().equals(first)) {
					return 1;
				} else if (getFork().equals(first)) {
					return -1;
				}
			}
			return getKey().toLowerCase().compareTo(o.getKey().toLowerCase());
		}

		@Override
		public String toString() {
			return getKey();
		}

	}

	@Override
	public void run() throws SmartServiceException {
		GetForks gf = new GetForks();
		RepositoryService service = super.createRepositoryService();

		List<String> forks = new ArrayList<String>();
		List<String> branches = new ArrayList<String>();
		List<String> revisions = new ArrayList<String>();
		List<String> refspecs = new ArrayList<String>();
		Set<Branch> bag = new TreeSet<Branch>();

		String firstOwner = null;
		try {
			for (String owner : gf.getForks(repositoryOwner, repositoryName)) {
				if (firstOwner == null) {
					firstOwner = owner;
					Branch.setFirst(firstOwner);
				}
				for (RepositoryBranch branch : service.getBranches(new RepositoryId(repositoryOwner, repositoryName))) {
					Branch b = new Branch(owner, branch.getName(), branch.getCommit().getSha());
					bag.add(b);
				}
			}
			cache.set(bag);
		} catch (IOException e) {
			if (cache.get() == null) {
				throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
			}
			bag = cache.get();
		}

		for (Branch b : bag) {
			forks.add(b.getFork());
			branches.add(b.getBranch());
			revisions.add(b.getRevision());
			refspecs.add(b.getKey());
		}

		fork = forks.toArray(new String[forks.size()]);
		branch = branches.toArray(new String[branches.size()]);
		revision = revisions.toArray(new String[revisions.size()]);
		refspec = refspecs.toArray(new String[refspecs.size()]);
	}
}
