package com.appiancorp.plugins.github.smartservices.deprecated;

import java.util.List;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.schema.Team;
import com.github.api.v2.services.OrganizationService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class GetOrganizationTeamsV2 extends GithubSmartServiceV2 {
	private String organizationName;
	
	private String[] teamNames;
	private String[] teamIds;
	
	@Override
	public void run() throws SmartServiceException {
		OrganizationService service = getOrganizationService();
		
		List<Team> teams = service.getTeams(organizationName);
		teamNames = new String[teams.size()];
		teamIds = new String[teams.size()];
		
		int i = 0;
		
		for(Team team : teams) {
			teamNames[i] = team.getName();
			teamIds[i] = team.getId();
			i++;
		}
		
	}

	public String[] getTeamNames() {
		return teamNames;
	}

	public String[] getTeamIds() {
		return teamIds;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
}
