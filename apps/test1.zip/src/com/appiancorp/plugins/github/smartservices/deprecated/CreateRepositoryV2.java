package com.appiancorp.plugins.github.smartservices.deprecated;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.schema.Repository;
import com.github.api.v2.services.RepositoryService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class CreateRepositoryV2 extends GithubSmartServiceV2 {

	private String name;
	private String description;
	private String homepageURL;
	private String visibility;
		
	private String repositoryName;
	
	@Override
	public void run() throws SmartServiceException {
		RepositoryService service = getRepositoryService();
				
		Repository newRepo = service.createRepository(name, description, homepageURL, Repository.Visibility.fromValue(visibility));
		this.repositoryName = newRepo.getName();
	}

	public void setName(String name) {
		this.name = name;
	}

	@Input(required=Required.OPTIONAL)
	public void setDescription(String description) {
		this.description = description;
	}

	@Input(required=Required.OPTIONAL)
	public void setHomepageURL(String homepageURL) {
		this.homepageURL = homepageURL;
	}

	@Input(enumeration = "Visibility")
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getRepositoryName() {
		return repositoryName;
	}
}
