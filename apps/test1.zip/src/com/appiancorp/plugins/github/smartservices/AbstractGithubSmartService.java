package com.appiancorp.plugins.github.smartservices;

import org.eclipse.egit.github.core.service.OrganizationService;
import org.eclipse.egit.github.core.service.RepositoryService;
import org.eclipse.egit.github.core.service.TeamService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.AppianSmartService;

public abstract class AbstractGithubSmartService extends AppianSmartService {
	protected static final String GITHUB_SERVICES = "GitHub Services";
	protected static final String PRIVATE = "private";
	protected static final String ERROR_GITHUB_IO = "error.github.io";
	
	protected String accessToken;

	public RepositoryService createRepositoryService() {
		RepositoryService service = new RepositoryService();
		
		service.getClient().setOAuth2Token(accessToken);
		
		return service;
	}
	
	public OrganizationService createOrganizationService() {
		OrganizationService service = new OrganizationService();
		
		service.getClient().setOAuth2Token(accessToken);
		
		return service;
	}
	
	public TeamService createTeamService() {
		TeamService service = new TeamService();
		
		service.getClient().setOAuth2Token(accessToken);
		
		return service;
	}
	
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	protected SmartServiceException createException(Exception e, Class clazz,
			String key, Object... args) {
		SmartServiceException.Builder sseb = new SmartServiceException.Builder(
				clazz, e.getCause());
		return sseb.userMessage(key, args).build();
	}
}
