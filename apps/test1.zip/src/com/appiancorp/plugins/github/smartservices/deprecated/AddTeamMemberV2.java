package com.appiancorp.plugins.github.smartservices.deprecated;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.services.OrganizationService;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class AddTeamMemberV2 extends GithubSmartServiceV2 {
	private String userToAdd;
	private String teamId;
	
	@Override
	public void run() throws SmartServiceException {
		OrganizationService service = getOrganizationService();
				
		service.addTeamMember(teamId, userToAdd);
	}

	public void setUserToAdd(String userToAdd) {
		this.userToAdd = userToAdd;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
}
