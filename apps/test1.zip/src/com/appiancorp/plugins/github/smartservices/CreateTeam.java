package com.appiancorp.plugins.github.smartservices;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.eclipse.egit.github.core.Team;
import org.eclipse.egit.github.core.service.TeamService;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.INTEGRATION_SERVICES, palette=AbstractGithubSmartService.GITHUB_SERVICES)
public class CreateTeam extends AbstractGithubSmartService {
	private static final Logger LOG = Logger.getLogger(AddTeamMember.class);

	private String organizationName;
	private String teamName;
	private String permission;
		
	private int teamId;
	
	@Override
	public void run() throws SmartServiceException {
		TeamService service = super.createTeamService();
		
		Team team = new Team().setName(teamName).setPermission(permission);
				
		try {
			team = service.createTeam(organizationName, team);
			teamId = team.getId();
		} catch (IOException e) {
			throw createException(e, this.getClass(), ERROR_GITHUB_IO, e.getMessage());
		}
	}

	@Input(required=Required.ALWAYS)
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	@Input(required=Required.ALWAYS)
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	@Input(enumeration = "Permission", required=Required.ALWAYS)
	public void setPermission(String permission) {
		this.permission = permission;
	}

	public int getTeamId() {
		return teamId;
	}

}
