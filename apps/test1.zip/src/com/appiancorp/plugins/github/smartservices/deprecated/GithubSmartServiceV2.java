package com.appiancorp.plugins.github.smartservices.deprecated;

import com.appiancorp.suiteapi.process.framework.AppianSmartService;
import com.github.api.v2.services.GitHubServiceFactory;
import com.github.api.v2.services.OrganizationService;
import com.github.api.v2.services.RepositoryService;
import com.github.api.v2.services.auth.LoginTokenAuthentication;

public abstract class GithubSmartServiceV2 extends AppianSmartService {
	protected String username;
	protected String apiToken;
	
	protected OrganizationService getOrganizationService() {
		GitHubServiceFactory factory = GitHubServiceFactory.newInstance();
		OrganizationService service = factory.createOrganizationService();
		service.setAuthentication(new LoginTokenAuthentication(username, apiToken));
		
		return service;
	}
	
	protected RepositoryService getRepositoryService() {
		GitHubServiceFactory factory = GitHubServiceFactory.newInstance();
		RepositoryService service = factory.createRepositoryService();
		service.setAuthentication(new LoginTokenAuthentication(username, apiToken));
		
		return service;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}
}
