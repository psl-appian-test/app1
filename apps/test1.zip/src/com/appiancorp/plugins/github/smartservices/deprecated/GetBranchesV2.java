package com.appiancorp.plugins.github.smartservices.deprecated;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicReference;

import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.palette.PaletteCategoryConstants;
import com.appiancorp.suiteapi.process.palette.PaletteInfo;
import com.github.api.v2.services.GitHubException;
import com.github.api.v2.services.GitHubServiceFactory;
import com.github.api.v2.services.RepositoryService;
import com.github.api.v2.services.auth.Authentication;
import com.github.api.v2.services.auth.LoginTokenAuthentication;

@PaletteInfo(paletteCategory=PaletteCategoryConstants.HIDDEN_CATEGORY, palette=PaletteCategoryConstants.HIDDEN_CATEGORY)
public class GetBranchesV2 extends GithubSmartServiceV2 {
	private String repositoryName;
	private String[] fork, branch, revision, refspec;
	private static final AtomicReference<Set<Branch>> cache = new AtomicReference<Set<Branch>>();

	public void setRepositoryName(String repositoryName) {
	  this.repositoryName = repositoryName;
	}

	public String[] getFork() {
	  return fork;
	}

	public String[] getBranch() {
	  return branch;
	}

	public String[] getRevision() {
	  return revision;
	}

	public String[] getRefspec() {
	  return refspec;
	}

	private static class Branch implements Comparable<Branch> {
	  private String fork;
	  private String branch;
	  private String revision;
	  private static String first;
	  public Branch(String fork, String branch, String revision) {
	    this.fork = fork;
	    this.branch = branch;
	    this.revision = revision;
	  }

	  public static void setFirst(String first) {
	    Branch.first = first;
	  }

	  public String getFork() {
	    return fork;
	  }

	  public String getBranch() {
	    return branch;
	  }

	  public String getRevision() {
	    return revision;
	  }

	  public String getKey() {
	    return String.format("%s/%s/%s", fork, branch, revision);
	  }

    @Override
    public int compareTo(Branch o) {
      if(getFork().equals(o.getFork())) {
        return getKey().compareTo(o.getKey());
      }
      if(first != null) {
        if(o.getFork().equals(first)) {
          return 1;
        } else if(getFork().equals(first)) {
          return -1;
        }
      }
      return getKey().toLowerCase().compareTo(o.getKey().toLowerCase());
    }

    @Override
    public String toString() {
      return getKey();
    }

	}

	@Override
	public void run() throws SmartServiceException {
	  GitHubServiceFactory factory = GitHubServiceFactory.newInstance();
	  Authentication auth = new LoginTokenAuthentication(username, apiToken);
	  GetForksV2 gf = new GetForksV2();
	  RepositoryService repoService = factory.createRepositoryService();
	  repoService.setAuthentication(new LoginTokenAuthentication(username, apiToken));
	  List<String> forks = new ArrayList<String>();
	  List<String> branches = new ArrayList<String>();
	  List<String> revisions = new ArrayList<String>();
	  List<String> refspecs = new ArrayList<String>();
	  Set<Branch> bag = new TreeSet<Branch>();

	  String firstOwner = null;
	  try {
  	  for(String owner : gf.getForks(factory, auth, username, repositoryName)) {
  	    if(firstOwner == null) {
  	      firstOwner = owner;
  	      Branch.setFirst(firstOwner);
  	    }
  	    for(Map.Entry<String, String> e : repoService.getBranches(owner, repositoryName).entrySet()) {
  	      Branch b = new Branch(owner, e.getKey(), e.getValue());
  	      bag.add(b);
  	    }
  	  }
  	  cache.set(bag);
	 } catch(GitHubException e) {
	   if(cache.get() == null) {
	     throw e;
	   }
	   bag = cache.get();
	 }

	  for(Branch b : bag) {
	    forks.add(b.getFork());
	    branches.add(b.getBranch());
	    revisions.add(b.getRevision());
	    refspecs.add(b.getKey());
	  }

	  fork = forks.toArray(new String[forks.size()]);
	  branch = branches.toArray(new String[branches.size()]);
	  revision = revisions.toArray(new String[revisions.size()]);
	  refspec = refspecs.toArray(new String[refspecs.size()]);
	}
}
