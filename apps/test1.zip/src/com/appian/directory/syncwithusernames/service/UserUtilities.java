package com.appian.directory.syncwithusernames.service;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.appiancorp.suiteapi.common.exceptions.InvalidUserException;
import com.appiancorp.suiteapi.personalization.UserProfile;
import com.appiancorp.suiteapi.personalization.UserProfileService;
import com.appiancorp.suiteapi.personalization.UserValidationUtils;

public final class UserUtilities {

	private static final Logger LOG = Logger.getLogger(UserUtilities.class);

	/**
	 * These constants are hardcoded into the adduser.jsp page. If a username
	 * does match these restrcistions, it is not valid
	 */
	private static final int USERNAME_MIN_LENGTH = 1;
	private static final int USERNAME_MAX_LENGTH = 255;

	/**
	 * Checks to see if a given user, identified by username, is a system
	 * administrator user. The method uses the passed-in service context to get
	 * the UserProfileService to retrieve the UserProfile object, which is then
	 * checked for user type.
	 * 
	 * @param username_
	 *            the username of the user to check
	 * @param sc_
	 *            the service context to use when checking the UserProfile
	 *            object
	 * @return true if the user is identified by user type as a System
	 *         Administrator
	 * @throws InvalidUserException
	 *             if the user doesn't exist
	 */
	public static boolean isSystemAdmin(String username_, UserProfileService ups)
			throws InvalidUserException {
		boolean isAdmin = false;

		UserProfile u = ups.getUser(username_);
		isAdmin = (UserProfile.USER_TYPE_SYS_ADMIN).equals(u.getUserTypeId());
		return isAdmin;
	}

	/**
	 * Checks to see if a given user, identified by username, is currently
	 * deactivated. The method gets the service context using the passed-in
	 * username, and then checks if the current user is deactivated.
	 * 
	 * @param username_
	 *            the username of the user to check
	 * @return true if the user is deactivated
	 */
	public static boolean isUserDeactivated(String username_,
			UserProfileService ups_) {
		UserProfile u = ups_.getUser(username_);
		return UserProfile.STATUS_DEACTIVATED == u.getStatus();
	}

	/**
	 * Validates a UserProfile object to the minimum requirements: a present and
	 * valid username, email address, first name, and last name.
	 * 
	 * @param user_
	 *            the UserProfile object to validate
	 * @return true if the username, email address, first name, and last name
	 *         are present and valid according to their respective validation
	 *         methods
	 * 
	 */
	public static boolean validateProfileBasic(UserProfile user_) {

		boolean valid = true;

		valid = (valid && isUsernameValid(user_.getUsername()));
		valid = (valid && UserValidationUtils.isValidEmail(user_.getEmail()));
		valid = (valid && isNameValid(user_.getFirstName(),	UserValidationUtils.FN_FIELD));
		valid = (valid && isNameValid(user_.getLastName(), UserValidationUtils.LN_FIELD));

		if (valid)
			LOG.debug("profile is valid using basic validation");
		else
			LOG.debug("profile is invalid");

		return valid;
	}

	
	/**
	 * Validates a name for minimum requirements:
	 * 
	 * @param name
	 *            the name to validate
	 * @return true if the name is valid
	 * 
	 */
	public static boolean isNameValid(String name, int nameType) {

		boolean valid = false;
		
		if(StringUtils.isEmpty(name)) {
			valid = false;
		} else {
			valid = UserValidationUtils.isValidName(name) 
				&& UserValidationUtils.isValidNameLength(name, nameType);
		}
		
		if (!valid) {
			LOG.debug("name " + name + " is invalid");
		}

		return valid;
	}

	/**
	 * Validates a username for minimum requirements:
	 * 
	 * @param username_
	 *            the username to validate
	 * @return true if the username is valid
	 * 
	 */
	public static boolean isUsernameValid(String username_) {

		boolean valid = (UserValidationUtils.isValidUsername(username_)
				&& (username_.length() >= USERNAME_MIN_LENGTH) && (username_
				.length() <= USERNAME_MAX_LENGTH));

		if (!valid) {
			LOG.debug("username " + username_ + " is invalid");
		}

		return valid;
	}

}
