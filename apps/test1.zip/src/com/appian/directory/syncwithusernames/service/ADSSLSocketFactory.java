package com.appian.directory.syncwithusernames.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyStore;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.SSLContext;

import org.apache.log4j.Logger;

public class ADSSLSocketFactory extends SSLSocketFactory {
  private SSLSocketFactory socketFactory;
  
  private static String keystorePath;
  
  private static final Logger LOG = Logger
      .getLogger(ADSSLSocketFactory.class);
  
  public ADSSLSocketFactory() {
    try {
      KeyStore keystore = KeyStore.getInstance("JKS");
      keystore.load(new FileInputStream(keystorePath), null);
      TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      tmf.init(keystore);
      SSLContext ctx = SSLContext.getInstance("TLS");
      ctx.init(null,  tmf.getTrustManagers(), null);
      socketFactory = ctx.getSocketFactory();
    } catch (Exception e) {
      LOG.error(e.getMessage());
      throw new RuntimeException(e);
    }

  }
  public static SocketFactory getDefault() {
    return new ADSSLSocketFactory();
  }
  
  public static void setKeystorePath(String path) {
    keystorePath = path;
  }

  @Override
  public String[] getDefaultCipherSuites() {
    return socketFactory.getDefaultCipherSuites();
  }

  @Override
  public String[] getSupportedCipherSuites() {
    return socketFactory.getSupportedCipherSuites();
  }
  
  @Override
  public Socket createSocket()
      throws IOException {
    return socketFactory.createSocket();
  }

  @Override
  public Socket createSocket(Socket s, String host, int port, boolean autoClose)
      throws IOException {
    return socketFactory.createSocket(s, host, port, autoClose);
  }
  
  @Override
  public Socket createSocket(String host, int port) throws IOException,
      UnknownHostException {
    return socketFactory.createSocket(host, port);
  }

  @Override
  public Socket createSocket(InetAddress host, int port) throws IOException {
    return socketFactory.createSocket(host, port);
  }

  @Override
  public Socket createSocket(String host, int port, InetAddress localHost,
      int localPort) throws IOException, UnknownHostException {
    return socketFactory.createSocket(host, port, localHost, localPort);
  }

  @Override
  public Socket createSocket(InetAddress address, int port,
      InetAddress localAddress, int localPort) throws IOException {
    return socketFactory.createSocket(address, port, localAddress, localPort);
  }
  
}
