package com.appian.directory.syncwithusernames.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.appiancorp.plugin.directory.type.LdapSyncConfig;
import com.appiancorp.services.ServiceContext;
import com.appiancorp.services.exceptions.ServiceException;
import com.appiancorp.suiteapi.common.exceptions.InvalidUserException;
import com.appiancorp.suiteapi.personalization.UserProfile;
import com.appiancorp.suiteapi.personalization.UserProfileService;
import com.appiancorp.suiteapi.personalization.UserService;
import com.appiancorp.suiteapi.content.Content;
import com.appiancorp.suiteapi.content.ContentConstants;
import com.appiancorp.suiteapi.content.ContentOutputStream;
import com.appiancorp.suiteapi.content.ContentService;
import com.appiancorp.suiteapi.content.exceptions.InvalidContentException;
import com.appiancorp.suiteapi.knowledge.Document;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Transparency;

public class SynchronizationService {
	private static final Logger LOG = Logger.getLogger(SynchronizationService.class);
	private static final int MAXIMUM_RECURSION_COUNTER = 50;
	private static final int[] USER_THUMBNAIL_WIDTHS = { 60, 90, 180 };
	private static final int USER_PROFILE_PICTURE_WIDTH = USER_THUMBNAIL_WIDTHS[0];
	
	private static final String APPIAN_USERNAME_ATTRIBUTE_NAME = "username";
	private static final String LDAP_CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
	private static final String LDAP_CONNECTION_POOL_ATTRIBUTE_NAME = "com.sun.jndi.ldap.connect.pool";
	private static final String LDAP_CONNECTION_TIMEOUT_ATTRIBUTE_NAME = "com.sun.jndi.ldap.connect.timeout";
	private static final String LDAP_NAMING_LDAP_FACTORY_SOCKET = "java.naming.ldap.factory.socket";
	private static final String SYSTEM_TRUSTSTORE_ENV_NAME = "javax.net.ssl.trustStore";
	private static final String SSL_SECURITY_PROTOCOL = "ssl";
	
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CITY = "city";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_COUNTRY = "country";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS1 = "address1";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS2 = "address2";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS3 = "address3";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_ZIPCODE = "zipCode";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_STATE = "state";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD1 = "customField1";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD2 = "customField2";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD3 = "customField3";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD4 = "customField4";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD5 = "customField5";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD6 = "customField6";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD7 = "customField7";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD8 = "customField8";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD9 = "customField9";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD10 = "customField10";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_EMAIL = "email";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_DISPLAYNAME = "displayName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_FIRSTNAME = "firstName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_LASTNAME = "lastName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_MIDDLENAME = "middleName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_PHONEHOME = "phoneHome";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_PHONEMOBILE = "phoneMobile";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_PHONEOFFICE = "phoneOffice";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_SUPERVISORNAME = "supervisorName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_TITLENAME = "titleName";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_USERNAME = "username";
	private static final String APPIAN_USER_PROFILE_ATTRIBUTE_PROFILE_PHOTO = "profilePhoto";
	
	private LdapContext _conn;
	private Map<String,String> attributesMap;
	private String[] attributesToSynchronize;
	private ContentService cs;
	private UserProfileService ups;
	private UserService us;
	private Long userPicturesFolder;
	private Long userThumbnailsFolder;

	public Map<String, Object> synchronizeUsers(LdapSyncConfig config, ContentService cs,  UserProfileService ups, UserService us, ServiceContext sc) {
		//init the map containing the synch results
		Map<String, Object> returnMap = new HashMap<String, Object> ();
		returnMap.put(SynchronizationUtilities.USERS_CREATED, new Long(0));
		returnMap.put(SynchronizationUtilities.USERS_DEACTIVATED, new Long(0));
		returnMap.put(SynchronizationUtilities.USERS_REACTIVATED, new Long(0));
		returnMap.put(SynchronizationUtilities.USERS_UPDATED, new Long(0));
		
		returnMap.put(SynchronizationUtilities.USERNAMES_CREATED, new String[]{});
		returnMap.put(SynchronizationUtilities.USERNAMES_DEACTIVATED, new String[]{});
		returnMap.put(SynchronizationUtilities.USERNAMES_REACTIVATED, new String[]{});
		returnMap.put(SynchronizationUtilities.USERNAMES_UPDATED, new String[]{});
		
		//list containing the list of usernames that failed sync
		List<String> failedUsernames = new ArrayList<String> ();
		
		this.cs = cs;
		this.ups = ups;
		this.us = us;

		this.userPicturesFolder = cs.getIdByUuid(ContentConstants.UUID_USER_PICTURES_FOLDER);
		this.userThumbnailsFolder = cs.getIdByUuid(ContentConstants.UUID_USER_THUMBNAILS_FOLDER);

		try {
			LOG.debug("Getting accounts to activate");
			String[] searchParameters = new String[3];
			searchParameters[0] = config.getAuthenticationBaseDN();
			searchParameters[1] = config.getSynchUserFilter();
			searchParameters[2] = String.valueOf(SearchControls.SUBTREE_SCOPE);
			List<UserProfile> accountsToActivate = getUserProfiles(searchParameters, config, failedUsernames);

			List<UserProfile> accountsToDeactivate = new ArrayList<UserProfile>();
			if (StringUtils.isNotEmpty(config.getSynchUserDeactivatedBaseDN())) {

				LOG.debug("Getting accounts to deactivate");
				searchParameters[0] = config.getSynchUserDeactivatedBaseDN();
				searchParameters[1] = config.getSynchUserDeactivatedFilter();
				accountsToDeactivate = getUserProfiles(searchParameters, config, failedUsernames);
			}

			LOG.debug("resolving accounts");
			//loop until one of the following conditions is met:
			// - all accounts retrieved from LDAP have been resolved, OR
			// - the remaining accounts retrieved from LDAP cannot be resolved (2 consecutive loops work on the base accounts), OR
			// - the maximum number of loops has been reached. This is set to 50
			int maxRecursionCount = MAXIMUM_RECURSION_COUNTER;
			List<UserProfile> accountsToRetry = null;
			
			while (maxRecursionCount > 0) {
				maxRecursionCount --;
				
				accountsToRetry = SynchronizationUtilities.resolveAccounts(accountsToActivate, 
						accountsToDeactivate, config.getSynchUserReactivate(), returnMap,
						us, ups, sc);
				
				//break the loop if all accounts have been resolved
				if (accountsToRetry == null || accountsToRetry.size() == 0) {
					if (LOG.isDebugEnabled()) {
						LOG.debug("All user accounts retrieved from LDAP have been synched");
					}
					break;
				}
				
				//break the loop if no account have been resolved in this loop
				if (accountsToRetry.size() == accountsToActivate.size()) {
					
					if (LOG.isDebugEnabled()) {
						LOG.debug(accountsToRetry.size() + " user accounts could NOT be resolved: ");
					}
										
					for (UserProfile profile : accountsToRetry) {
						if (LOG.isDebugEnabled()) {
							LOG.debug(" - user " + profile.getUsername() + " failed to synch");
						}
						//add the user account to the list of accounts that failed sync
						failedUsernames.add(profile.getUsername());
					}
					
					break;
				}
				
				//continue looping
				accountsToActivate = accountsToRetry;
				accountsToDeactivate = new ArrayList<UserProfile>();
			}
			
			//add the accounts that failed sync into the return map
			returnMap.put(SynchronizationUtilities.USERS_FAILED, failedUsernames.toArray(new String[failedUsernames.size()]));
			

		} catch (Exception e) {
			LOG.error("Error occured during the synchronization: " + e.getMessage(), e);
			throw new ServiceException(e);
		}		
		return returnMap;
	}

	/**
	 * Execute a search against LDAP to retrieve all user accounts matching a specific filter passed as parameter.
	 * Encapsualte the values returned by LDAP into UserProfile objects
	 * 
	 * @param params contains the parameters for the LDAP search
	 * @param config contains the smart service configuration
	 * @return
	 */
	private List<UserProfile> getUserProfiles(String[] params, LdapSyncConfig config, List<String> failedUsernames){

		List<UserProfile> profiles = new ArrayList<UserProfile>();
		// first, set up the search parameters
		String basedn = params[0];
		String filter = params[1];
		int scope = Integer.valueOf(params[2]).intValue();

		SearchControls ctls = new SearchControls();
		ctls.setReturningAttributes(attributesToSynchronize);
		ctls.setSearchScope(scope);
		ctls.setReturningObjFlag(false);

		LOG.debug("Attempting to get UserProfile objects from directory search.  basedn: " + basedn + " - filter: " + filter
				+ " - scope:  " + scope);

		// then execute the search and get the profiles List ready
		List<SearchResult> results = search(basedn, filter, ctls, config);

		// if the search returns nothing, then return the empty list
		if (results.isEmpty()) {
			LOG.debug("Search returned no results");
			return profiles;
		}

		// otherwise, we've got search results and we need to turn them into a
		// List of UserProfile objects
		for (SearchResult entry : results) {
			// get the LDAP entry and its attributes
			Attributes atts = entry.getAttributes();

			// if the attributes are null, then move to the next entry - this
			// one's invalid for our purposes
			if (atts == null || atts.size() <= 0)
				continue;

			// convert the attributes to a map - if somehow we've still got an
			// empty or null attributes map, then move to the next entry because
			// it's invalid
			NamingEnumeration<?> ne = atts.getAll();
			Map<String,Object> ldapAttributes = new HashMap<String,Object>();

			try {
				while (ne.hasMore()) {
					Attribute attribute = (Attribute) ne.next();
					if (null != attribute) {
						ldapAttributes.put(attribute.getID(), attribute.get());
					}
				}
			} catch (NamingException e) {
				LOG.error("Error while reading the attributes from LDAP", e);
			}
			if (ldapAttributes.isEmpty())
				continue;

			// get the username from the attributes list and attempt to get the
			// UserProfile from the ASL service. If it doesn't exist, that's
			// fine, just continue with the null object
			UserProfile profile = null;
			String ldapUsernameAttrName = attributesMap.get(APPIAN_USERNAME_ATTRIBUTE_NAME);
			String un = (String) ldapAttributes.get(ldapUsernameAttrName);
			//lowercase the username is necessary
			if (config.getSynchLowercaseUsername() && un != null) 
				un = un.toLowerCase();
			
			if (StringUtils.isNotEmpty(un)) {
				if (us.doesUserExist(un)) {
					try {
						profile = ups.getUser(un);
					} catch (InvalidUserException e) {
						//this should never happen
						LOG.debug(un + " didn't exist - creating profile from Directory Attributes");
						LOG.debug(un + " didn't exist - creating profile from Directory Attributes");
					}
				} else {
					LOG.debug(un + " didn't exist - creating profile from Directory Attributes");
					LOG.debug(un + " didn't exist - creating profile from Directory Attributes");
				}
			}

			// fill the user profile using the attributes map that was pulled
			// from LDAP
			UserProfile p = fillUserProfile(profile, ldapAttributes, config);

			// if the profile comes back non-null and the profile validates,
			// then add it to the profiles List
			if (p != null && UserUtilities.validateProfileBasic(p)) {
				profiles.add(p);

				try {
					updatePhoto(p, ldapAttributes, config);
				} catch (Exception e) {
					LOG.error("Error occured while updating user profile photos for " + p.getUsername(), e);
				}
			} else {
				//the profile failed validation
				//add the profile into the list of failed accounts
				if (p != null) {
					LOG.debug(" - user " + p.getUsername() + " failed to synch");
					LOG.debug(" - user " + p.getUsername() + " failed to synch");
					failedUsernames.add(p.getUsername());
				}
			}
		}
		LOG.debug("Search returned " + profiles.size() + " user profiles");
		LOG.debug("Search returned " + profiles.size() + " user profiles");

		return profiles;
	}

	/**
	 * Execute the search against LDAP and return a list of LDAP SearchResult objects
	 * 
	 * @param name_
	 * @param filter_
	 * @param controls_
	 * @param config
	 * @return
	 */
	private List<SearchResult> search(String name_, String filter_, SearchControls controls_, LdapSyncConfig config) {

		List<SearchResult> results = new ArrayList<SearchResult>();

		NamingEnumeration<?> sr = null;
		try {
			// if we support the paging control, repeatedly execute the search command against the directory server,
			// appending the results to the list
			if (config.getPageControlSupported()) {
				byte[] cookie = null;

				Control[] ctls = new Control[] { new PagedResultsControl(config.getPageControlPageSize().intValue(), Control.CRITICAL) };
				_conn.setRequestControls(ctls);

				do {
					// search and get the first set, adding the results to the list
					sr = _conn.search(name_, filter_, controls_);
					try{
						while (sr != null && sr.hasMore()) {
							results.add((SearchResult) sr.next());
						}
					}catch(NamingException e){
						LOG.error("Error while conducting name search: " +e, e);
					}

					// evaluate the paging cookie, and then reset the control for the next time around
					cookie = parseControls(_conn.getResponseControls());
					_conn.setRequestControls(new Control[] { new PagedResultsControl(config.getPageControlPageSize().intValue(), cookie,
							Control.CRITICAL) });

				} while ((cookie != null) && (cookie.length != 0));

			} else {
				// if there's no paging control then execute the search once and get the full result set
				sr = _conn.search(name_, filter_, controls_);
				while (sr != null && sr.hasMore()) {
					results.add((SearchResult) sr.next());
				}
			}
		} catch (IOException e) {
			LOG.error("error while searching against LDAP", e);
			throw new ServiceException(e);
		} catch (NamingException e) {
			LOG.error("error while searching against LDAP", e);
			throw new ServiceException(e);
		} finally {
			if (sr != null)
				try {
					sr.close();
				} catch (NamingException e) {
					LOG.error("error while finalizing the search against LDAP", e);
				}
		}
		return results;
	}

	private byte[] parseControls(Control[] controls) throws NamingException {
		LOG.debug("parsing controls for next page");

		byte[] cookie = null;
		if (controls != null) {
			for (int i = 0; i < controls.length; i++) {
				LOG.debug("class name:    " + controls[i].getClass().getName());
				LOG.debug("control id:    " + controls[i].getID());
				LOG.debug("encoded value: " + new String(controls[i].getEncodedValue()));
				LOG.debug("is critical:   " + controls[i].isCritical());

				if (controls[i] instanceof PagedResultsResponseControl) {
					PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
					cookie = prrc.getCookie();

					if (cookie != null) {
						LOG.debug("cookie value: " + new String(cookie));
					} else {
						LOG.debug("cookie is null");
					}
					
					return (cookie == null)	? new byte[0] : cookie;
				}
			}
		} else {
			LOG.error("controls is a null object, the paging control is NOT supported");
		}
		return new byte[0];
	}

	private UserProfile fillUserProfile(final UserProfile profile_, final Map<String,Object> attributes_, LdapSyncConfig config)
	throws ServiceException {

		String usernameAttr = attributesMap.get(APPIAN_USERNAME_ATTRIBUTE_NAME);
		String un = (String)attributes_.get(usernameAttr);

		UserProfile p = profile_;
		if (p == null) {
			p = new UserProfile();
		}

		// for each value in the attributes list, overwrite the value in profile
		Set<String> keys = attributesMap.keySet();
		for (String aeAttKey : keys) {

			// get the Appian's UserProfile attribute name, and then the directory attribute name
			String dirAttKey = attributesMap.get(aeAttKey);

			// then get the directory attribute value
			String dirAttValue = "";
			Object tempAttVal = attributes_.get(dirAttKey);
			if (tempAttVal instanceof String)
				dirAttValue = (String) tempAttVal;
			else if (tempAttVal instanceof Set) {
				Set mySet = (HashSet) tempAttVal;
				for (Iterator i = mySet.iterator(); i.hasNext();) {
					String toString = (i.next()).toString();
					dirAttValue = toString.substring(dirAttKey.length() + 2, toString.indexOf(","));
					break;
				}
			}
			LOG.debug("(AE key, DIR key, DIR value): ("+aeAttKey + ", " + dirAttKey + ", " + dirAttValue+")");

			// place the directory attribute value into the UserProfile object, using the AE attribute name
			if (StringUtils.isNotBlank(dirAttValue)) {
				String sn = "set" + StringUtils.capitalize(aeAttKey);
				
				try {
					Method setter = p.getClass().getMethod(sn, new Class[] { dirAttValue.getClass() });
					setter.invoke(p, new Object[] { dirAttValue });
				} catch (SecurityException e) {
					LOG.error("Error setting the UserProfile attribute " + aeAttKey + " with the value " 
							+ dirAttValue + " using the method " + sn, e);
				} catch (NoSuchMethodException e) {
					LOG.error("Error setting the UserProfile attribute " + aeAttKey + " with the value " 
							+ dirAttValue + " using the method " + sn, e);
				} catch (IllegalArgumentException e) {
					LOG.error("Error setting the UserProfile attribute " + aeAttKey + " with the value " 
							+ dirAttValue + " using the method " + sn, e);
				} catch (IllegalAccessException e) {
					LOG.error("Error setting the UserProfile attribute " + aeAttKey + " with the value " 
							+ dirAttValue + " using the method " + sn, e);
				} catch (InvocationTargetException e) {
					LOG.error("Error setting the UserProfile attribute " + aeAttKey + " with the value " 
							+ dirAttValue + " using the method " + sn, e);
				}
			}


		}

		if (config.getSynchLowercaseUsername()) {
			un = p.getUsername();
			if (StringUtils.isNotBlank(un))
				p.setUsername(un.toLowerCase());
		}

		String supervisor = p.getSupervisorName();
		if (StringUtils.isNotBlank(supervisor)) {
			String aup = config.getAuthenticationUserPrefix();
			String aus = config.getAuthenticationUserSuffix();
			supervisor = supervisor.replaceAll(" ", "");
			if (supervisor.startsWith(aup)) {
				supervisor = supervisor.substring(aup.length());
			}
			if (supervisor.endsWith(aus)) {
				supervisor = supervisor.substring(0, supervisor.length() - aus.length());
			}
			if (config.getSynchLowercaseUsername()) {
				supervisor = supervisor.toLowerCase();
			}
			p.setSupervisorName(supervisor.trim());
		}

		return p;
	}

	public LdapContext connect(LdapSyncConfig config){
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, LDAP_CONTEXT_FACTORY);
		env.put(Context.PROVIDER_URL, config.getConnectionUrl());
		env.put(LDAP_CONNECTION_POOL_ATTRIBUTE_NAME, config.getConnectionUsepool().toString());
		env.put(Context.REFERRAL, config.getConnectionReferral());
		env.put(LDAP_CONNECTION_TIMEOUT_ATTRIBUTE_NAME, config.getConnectionTimeout().toString());

		if (LOG.isDebugEnabled()) {
			LOG.debug("Connection Properties: ");
			LOG.debug(" " + Context.INITIAL_CONTEXT_FACTORY + ": " + LDAP_CONTEXT_FACTORY);
			LOG.debug(" " + Context.PROVIDER_URL + ": " + config.getConnectionUrl());
			LOG.debug(" " + LDAP_CONNECTION_POOL_ATTRIBUTE_NAME + ": " + config.getConnectionUsepool());
			LOG.debug(" " + Context.REFERRAL + ": " + config.getConnectionReferral());
			LOG.debug(" " + LDAP_CONNECTION_TIMEOUT_ATTRIBUTE_NAME + ": " + config.getConnectionTimeout());
		}
 
		if ("ssl".equals(config.getConnectionType())) {
            env.put(Context.SECURITY_PROTOCOL, SSL_SECURITY_PROTOCOL);
	        
            // Set KeyStore Path for use in custom SSLSocketFactory
            if (!config.getConnectionKeystore().isEmpty()) {
              ADSSLSocketFactory.setKeystorePath(config.getConnectionKeystore());
              env.put(LDAP_NAMING_LDAP_FACTORY_SOCKET, "com.appian.directory.syncwithusernames.service.ADSSLSocketFactory");
            }
            
			if (LOG.isDebugEnabled()) {
				LOG.debug(" " + Context.SECURITY_PROTOCOL + ": " + SSL_SECURITY_PROTOCOL);
				LOG.debug(" " + SYSTEM_TRUSTSTORE_ENV_NAME + ": " + config.getConnectionKeystore());
			}
		}

		env.put(Context.SECURITY_AUTHENTICATION, config.getAuthenticationType());
		env.put(Context.SECURITY_PRINCIPAL, config.getAuthenticationUserPrefix() + config.getAuthenticationUserName() + config.getAuthenticationUserSuffix());
		env.put(Context.SECURITY_CREDENTIALS, config.getAuthenticationUserPassword());
		if (LOG.isDebugEnabled()) {
			LOG.debug(" " + Context.SECURITY_AUTHENTICATION + ": " + config.getAuthenticationType());
			LOG.debug(" " + Context.SECURITY_PRINCIPAL + ": " + config.getAuthenticationUserPrefix() + config.getAuthenticationUserName() + config.getAuthenticationUserSuffix());
		}
		try{
			_conn = new InitialLdapContext(env, null);
		} catch (AuthenticationException e) {
			LOG.error("Domain authentication failed for " + config.getAuthenticationUserPrefix() 
					+ config.getAuthenticationUserName() + config.getAuthenticationUserSuffix() 
					+" on "+ config.getConnectionUrl(), e);
			throw new ServiceException(e);
		} catch (CommunicationException e){
			LOG.error("Domain authentication failed for " + config.getAuthenticationUserPrefix() 
					+ config.getAuthenticationUserName() + config.getAuthenticationUserSuffix() 
					+" on "+ config.getConnectionUrl(), e);
			throw new ServiceException(e);
		}catch (NamingException e) {
			LOG.error("Domain authentication failed for " + config.getAuthenticationUserPrefix() 
					+ config.getAuthenticationUserName() + config.getAuthenticationUserSuffix() 
					+" on "+ config.getConnectionUrl(), e);
			throw new ServiceException(e);
		}
		
		return _conn;
	}

	public void closeConnection () throws ServiceException {
		if (_conn != null) {
			try {
				_conn.close();
			} catch (NamingException e) {
				LOG.error("error closing the LDAP connection", e);
				throw new ServiceException(e);
			}
		}
	}
	
	public void initAttributes(LdapSyncConfig config) {

		Map<String,String> attsMap = new HashMap<String,String>();
		List<String> list = new ArrayList<String>();

		if (StringUtils.isNotBlank(config.getUserAddressCity())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CITY, config.getUserAddressCity());
			list.add(config.getUserAddressCity());
		}
		if (StringUtils.isNotBlank(config.getUserAddressCountry())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_COUNTRY, config.getUserAddressCountry());
			list.add(config.getUserAddressCountry());
		}
		if (StringUtils.isNotBlank(config.getUserAddressLine1())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS1, config.getUserAddressLine1());
			list.add(config.getUserAddressLine1());
		}
		if (StringUtils.isNotBlank(config.getUserAddressLine2())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS2, config.getUserAddressLine2());
			list.add(config.getUserAddressLine2());
		}
		if (StringUtils.isNotBlank(config.getUserAddressLine3())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_ADDRESS3, config.getUserAddressLine3());
			list.add(config.getUserAddressLine3());
		}
		if (StringUtils.isNotBlank(config.getUserAddressPostalCode())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_ZIPCODE, config.getUserAddressPostalCode());
			list.add(config.getUserAddressPostalCode());
		}
		if (StringUtils.isNotBlank(config.getUserAddressState())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_STATE, config.getUserAddressState());
			list.add(config.getUserAddressState());
		}
		if (StringUtils.isNotBlank(config.getUserAddressProvince())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_STATE, config.getUserAddressProvince());
			list.add(config.getUserAddressProvince());
		}
		if (StringUtils.isNotBlank(config.getUserCustom1())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD1, config.getUserCustom1());
			list.add(config.getUserCustom1());
		}
		if (StringUtils.isNotBlank(config.getUserCustom2())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD2, config.getUserCustom2());
			list.add(config.getUserCustom2());
		}
		if (StringUtils.isNotBlank(config.getUserCustom3())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD3, config.getUserCustom3());
			list.add(config.getUserCustom3());
		}
		if (StringUtils.isNotBlank(config.getUserCustom4())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD4, config.getUserCustom4());
			list.add(config.getUserCustom4());
		}
		if (StringUtils.isNotBlank(config.getUserCustom5())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD5, config.getUserCustom5());
			list.add(config.getUserCustom5());
		}
		if (StringUtils.isNotBlank(config.getUserCustom6())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD6, config.getUserCustom6());
			list.add(config.getUserCustom6());
		}
		if (StringUtils.isNotBlank(config.getUserCustom7())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD7, config.getUserCustom7());
			list.add(config.getUserCustom7());
		}
		if (StringUtils.isNotBlank(config.getUserCustom8())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD8, config.getUserCustom8());
			list.add(config.getUserCustom8());
		}
		if (StringUtils.isNotBlank(config.getUserCustom9())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD9, config.getUserCustom9());
			list.add(config.getUserCustom9());
		}
		if (StringUtils.isNotBlank(config.getUserCustom10())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_CUSTOMFIELD10, config.getUserCustom10());
			list.add(config.getUserCustom10());
		}
		if (StringUtils.isNotBlank(config.getUserEmail())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_EMAIL, config.getUserEmail());
			list.add(config.getUserEmail());
		}
		if (StringUtils.isNotBlank(config.getUserDisplayName())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_DISPLAYNAME, config.getUserDisplayName());
			list.add(config.getUserDisplayName());
		}
		if (StringUtils.isNotBlank(config.getUserFirstName())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_FIRSTNAME, config.getUserFirstName());
			list.add(config.getUserFirstName());
		}
		if (StringUtils.isNotBlank(config.getUserLastName())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_LASTNAME, config.getUserLastName());
			list.add(config.getUserLastName());
		}
		if (StringUtils.isNotBlank(config.getUserMiddleName())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_MIDDLENAME, config.getUserMiddleName());
			list.add(config.getUserMiddleName());
		}
		if (StringUtils.isNotBlank(config.getUserPhoneHome())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_PHONEHOME, config.getUserPhoneHome());
			list.add(config.getUserPhoneHome());
		}
		if (StringUtils.isNotBlank(config.getUserPhoneMobile())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_PHONEMOBILE, config.getUserPhoneMobile());
			list.add(config.getUserPhoneMobile());
		}
		if (StringUtils.isNotBlank(config.getUserPhoneOffice())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_PHONEOFFICE, config.getUserPhoneOffice());
			list.add(config.getUserPhoneOffice());
		}
		if (StringUtils.isNotBlank(config.getUserSupervisorUsername())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_SUPERVISORNAME, config.getUserSupervisorUsername());
			list.add(config.getUserSupervisorUsername());
		}
		if (StringUtils.isNotBlank(config.getUserTitle())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_TITLENAME, config.getUserTitle());
			list.add(config.getUserTitle());
		}
		if (StringUtils.isNotBlank(config.getUserUsername())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_USERNAME, config.getUserUsername());
			list.add(config.getUserUsername());
		}
		if (StringUtils.isNotBlank(config.getUserProfilePhoto())) {
			attsMap.put(APPIAN_USER_PROFILE_ATTRIBUTE_PROFILE_PHOTO, config.getUserProfilePhoto());
			list.add(config.getUserProfilePhoto());
		}

		setAttributesMap(attsMap);

		if (list.size() > 0) {
			setAttributesToSynchronize((String[]) list.toArray(new String[list.size()]));
		}
	}

	public Map<String, String> getAttributesMap() {
		return attributesMap;
	}

	public void setAttributesMap(Map<String, String> attributesMap) {
		this.attributesMap = attributesMap;
	}

	public String[] getAttributesToSynchronize() {
		return attributesToSynchronize;
	}

	public void setAttributesToSynchronize(String[] attributesToSynchronize) {
		this.attributesToSynchronize = attributesToSynchronize;
	}

	/**
	 * This method takes in an image, a user name, the user picture folder, and the user thumbnail folder. It will either create
	 * the appropriate Appian documents for the user or will delete and create a new document if they already exist.
	 *
	 * The method makes heavy usage of code from the Image Utilities Smart Service made available by Lizzie Epstein
	 * and the Update User Profile Picture Smart Service made available by Macedon Technologies.
	 */
	
	private void updatePhoto(UserProfile p, Map<String, Object> ldapAttributes, LdapSyncConfig config) throws Exception {
		Object photoAttr = ldapAttributes.get(config.getUserProfilePhoto());

		if (photoAttr == null) {
			LOG.debug("No user profile photo found: " + p.getUsername());
			return;
		} else if (!(photoAttr instanceof byte[])) {
			LOG.debug("User profile photo attribute was not a byte array: " + p.getUsername());
			return;
		}

		BufferedImage bi = ImageIO.read(new ByteArrayInputStream((byte[]) photoAttr));
		String filename = p.getUsername().replace('.', '_'); 

		// Only generate the thumbnail images if the main image was updated
		if (makeProfilePhoto(bi, USER_PROFILE_PICTURE_WIDTH, filename, userPicturesFolder, true)) {
			// Resize the uploaded picture and either create\replace in the User Thumbnails Folder for each size
			for (int width : USER_THUMBNAIL_WIDTHS) {
				makeProfilePhoto(bi, width, filename + "_" + width, userThumbnailsFolder, false);
			}
		}
	}

	/**
	 * Retrieves a document by using its path from the specified root folder
	 *
	 * @param documentName_
	 * @param folder
	 * @return Document, if it exists, or null if the document can't be found
	 */
	private Content getDocumentByPath(String path, Long folder) {
		try {
			return cs.getByPath(folder, path);
		} catch (InvalidContentException e) {
			LOG.debug("Document "+path+" not found.");
			return null;
		}
	}

	public static Document createNewDocument(String name, String description, Long folderId, String extension) {
		Document document = new Document();
		document.setName(name);
		document.setDescription(description);
		document.setParent(folderId);
		document.setExtension(extension);
		return document;
	}

	/**
	 * Resizes an image to the appropriate size.
	 * 
	 * @param bi The original user profile image
	 * @param maxWidth The maximum width to resize the image to
	 * @param documentName The name of the document within Appian
	 * @param folder The folder within Appian to store the resized image to
	 * @param compareImage Whether to compare the resized image if an existing image already exists
	 * @return true if the image was updated and false is the existing image is the same
	 */
	private boolean makeProfilePhoto(BufferedImage bi, int maxWidth, String documentName, Long folder, boolean compareImage) throws Exception {
		// Get the scaled dimensions of the new image
		int[] newDimensions = getAppropriatelyScaledMaxWandH(bi.getWidth(), bi.getHeight(), maxWidth, 200000);
		BufferedImage scaledBI = getScaledInstance(bi, newDimensions[0], newDimensions[1], RenderingHints.VALUE_INTERPOLATION_BICUBIC, false);

		// Check if the scaled image matches what we already have on disk
		Content existingPhotoDoc = getDocumentByPath(documentName, folder);

		// Delete existing photo
		if (existingPhotoDoc != null) {
			if (compareImage) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(scaledBI, "jpeg", baos);

				try (
					InputStream newPhoto = new ByteArrayInputStream(baos.toByteArray());
					InputStream oldPhoto = new FileInputStream(cs.getInternalFilename(existingPhotoDoc.getId()))
				) {
					if (IOUtils.contentEquals(newPhoto, oldPhoto)) {
						LOG.debug("User profile photo has not changed: " + documentName);
						return false;
					}
				}
			}

			cs.delete(existingPhotoDoc.getId(), false);
		}

		// Create the new document and write the scaled picture content to disk
		Document doc = createNewDocument(documentName, "", folder, "jpeg");

		try (ContentOutputStream cos = cs.upload(doc, ContentConstants.UNIQUE_NONE)) {
			ImageIO.write(scaledBI, "jpeg", cos);
		}

		LOG.debug("Updated user profile photo: " + documentName);

		return true;
	}

	private static int[] getAppropriatelyScaledMaxWandH(int currW_, int currH_, int maxW_, int maxH_) {
		int[] dimensions = new int[2];

		// find max ratio
		float xratio = (float) maxW_ / (float) currW_;
		float yratio = (float) maxH_ / (float) currH_;

		// multiply both by lower 1.
		float ratio = Math.min(xratio, yratio);
		dimensions[0] = (int) (currW_ * ratio);
		dimensions[1] = (int) (currH_ * ratio);

		return dimensions;
	}

	/**
	 * Convenience method that returns a scaled instance of the provided {@code
	 * BufferedImage}.
	 *
	 * @param img
	 *            the original image to be scaled
	 * @param targetWidth
	 *            the desired width of the scaled instance, in pixels
	 * @param targetHeight
	 *            the desired height of the scaled instance, in pixels
	 * @param hint
	 *            one of the rendering hints that corresponds to {@code
	 *            RenderingHints.KEY_INTERPOLATION} (e.g. {@code
	 *            RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR}, {@code
	 *            RenderingHints.VALUE_INTERPOLATION_BILINEAR}, {@code
	 *            RenderingHints.VALUE_INTERPOLATION_BICUBIC})
	 * @param higherQuality
	 *            if true, this method will use a multi-step scaling technique
	 *            that provides higher quality than the usual one-step technique
	 *            (only useful in downscaling cases, where {@code targetWidth}
	 *            or {@code targetHeight} is smaller than the original
	 *            dimensions, and generally only when the {@code BILINEAR} hint
	 *            is specified)
	 * @return a scaled version of the original {@code BufferedImage}
	 */
	public static BufferedImage getScaledInstance(BufferedImage img, int targetWidth, int targetHeight, Object hint,
			boolean higherQuality) {
		int type = (img.getTransparency() == Transparency.OPAQUE) ? BufferedImage.TYPE_INT_RGB
				: BufferedImage.TYPE_INT_ARGB;
		BufferedImage ret = (BufferedImage) img;
		int w, h;
		if (higherQuality) {
			// Use multi-step technique: start with original size, then
			// scale down in multiple passes with drawImage()
			// until the target size is reached
			w = img.getWidth();
			h = img.getHeight();
		} else {
			// Use one-step technique: scale directly from original
			// size to target size with a single drawImage() call
			w = targetWidth;
			h = targetHeight;
		}

		do {
			if (higherQuality && w > targetWidth) {
				w /= 2;
				if (w < targetWidth) {
					w = targetWidth;
				}
			}

			if (higherQuality && h > targetHeight) {
				h /= 2;
				if (h < targetHeight) {
					h = targetHeight;
				}
			}

			BufferedImage tmp = new BufferedImage(w, h, type);
			Graphics2D g2 = tmp.createGraphics();
			g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
			g2.drawImage(ret, 0, 0, w, h, null);
			g2.dispose();

			ret = tmp;
		} while (w != targetWidth || h != targetHeight);

		return ret;
	}
}
