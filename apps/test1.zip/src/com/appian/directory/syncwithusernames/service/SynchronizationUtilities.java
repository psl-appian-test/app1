package com.appian.directory.syncwithusernames.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.appiancorp.services.ServiceContext;
import com.appiancorp.suiteapi.common.ServiceLocator;
import com.appiancorp.suiteapi.common.exceptions.DuplicateNameException;
import com.appiancorp.suiteapi.common.exceptions.InvalidNameException;
import com.appiancorp.suiteapi.common.exceptions.InvalidSupervisorException;
import com.appiancorp.suiteapi.common.exceptions.InvalidUserException;
import com.appiancorp.suiteapi.common.exceptions.PrivilegeException;
import com.appiancorp.suiteapi.content.ContentService;
import com.appiancorp.suiteapi.forums.DiscussionMetadataCoreService;
import com.appiancorp.suiteapi.personalization.UserProfile;
import com.appiancorp.suiteapi.personalization.UserProfileService;
import com.appiancorp.suiteapi.personalization.UserRank;
import com.appiancorp.suiteapi.personalization.UserService;
import com.appiancorp.suiteapi.portal.AdministrationService;
import com.appiancorp.suiteapi.process.ProcessDesignService;
import com.appiancorp.suiteapi.process.analytics2.ProcessAnalyticsService;

public class SynchronizationUtilities {

	private static final Logger LOG = Logger
			.getLogger(SynchronizationUtilities.class);

	protected static final String USERS_CREATED = "usersCreated";
	protected static final String USERS_DEACTIVATED = "usersDeactivated";
	protected static final String USERS_REACTIVATED = "usersReactivated";
	protected static final String USERS_UPDATED = "usersUpdated";
	protected static final String USERS_FAILED = "usersFailed";
	protected static final String USERNAMES_CREATED = "usernamesCreated";
	protected static final String USERNAMES_DEACTIVATED = "usernamesDeactivated";
	protected static final String USERNAMES_REACTIVATED = "usernamesReactivated";
	protected static final String USERNAMES_UPDATED = "usernamesUpdated";

	/**
	 * filter the accounts retrieve from LDAP to differentiate between accounts
	 * to update, create, activate or deactivate.
	 * 
	 * @param accountsToActivate_
	 * @param accountsToDeactivate_
	 * @param reactivateAccounts_
	 * @param returnMap
	 * @param us_
	 * @param ups_
	 * @param sc_
	 * @return
	 * @throws InvalidUserException
	 * @throws DuplicateNameException
	 * @throws InvalidNameException
	 * @throws PrivilegeException
	 * @throws InvalidSupervisorException
	 */
	public static List<UserProfile> resolveAccounts(
			final List<UserProfile> accountsToActivate_,
			final List<UserProfile> accountsToDeactivate_,
			final Boolean reactivateAccounts_, Map<String, Object> returnMap,
			UserService us_, UserProfileService ups_, ServiceContext sc_)
			throws InvalidUserException, DuplicateNameException,
			InvalidNameException, PrivilegeException {
		if (accountsToActivate_ == null || accountsToDeactivate_ == null
				|| ups_ == null) {
			throw new NullPointerException(
					"Arguments cannot be null. Accounts to activate:"
							+ accountsToActivate_
							+ " - accounts to deactivate: "
							+ accountsToDeactivate_ + "User profile service: "
							+ ups_);
		}

		List<UserProfile> create = new ArrayList<UserProfile>();
		List<String> reactivate = new ArrayList<String>();
		List<String> deactivate = new ArrayList<String>();
		List<UserProfile> update = new ArrayList<UserProfile>();
		List<UserProfile> retry = new ArrayList<UserProfile>();
		List<String> titles = new ArrayList<String>();
		List<String> newAccountUsernames = new ArrayList<String>();
		List<String> updateUsernames = new ArrayList<String>();
		
		
		for (UserProfile user : accountsToActivate_) {
			String un = user.getUsername();
			String title = user.getTitleName();

			if (StringUtils.isNotEmpty(un)) {

				if (StringUtils.isNotEmpty(title) && !titles.contains(title)) {
					// add the title to the to-resolve list if the title
					// isn't empty and if the list of already-gathered
					// titles doesn't contain it
					titles.add(StringUtils.trimToEmpty(title));
				}

				if (!us_.doesUserExist(un)) {
					// define the account as a basic user, and set the
					// password
					// to a 30-character random string
					user.setUserTypeId(UserProfile.USER_TYPE_BASIC);
					String pw = RandomStringUtils.randomAlphanumeric(30);
					user.setUserPassword(pw.getBytes());

					String supervisor = user.getSupervisorName();
					if (StringUtils.isEmpty(supervisor)
							|| (us_.doesUserExist(supervisor) && !UserUtilities
									.isUserDeactivated(supervisor, ups_))) {
						// only create the account if the supervisor field
						// is empty or valid and activated
						create.add(user);
						LOG.debug("adding " + user.getUsername()
								+ " to create list");

					} else {
						// if the supervisor is invalid or deactivated, it
						// may be because the profile is in the bulk synch
						// list still. add to the retry list for the next
						// recursion
						retry.add(user);
						LOG.debug("adding " + user.getUsername()
								+ " to retry list (invalid supervisor "
								+ supervisor + " )");
					}

				} else {
					if (UserUtilities.isUserDeactivated(un, ups_)) {
						if (reactivateAccounts_) {
							// only add the account to the reactivation list
							// if the user is deactivated and if the
							// reactivateAccounts flag was passed as true
							user.setUserTypeId(UserProfile.USER_TYPE_BASIC);
							reactivate.add(un);
							updateUsernames.add(un);
							update.add(user);
							LOG.debug("adding "
									+ user.getUsername()
									+ " to reactivate and update list as a basic user");
						}
					} else {
						// otherwise, the account is active and simply need
						// reactivation. If the account is set as system
						// administrator, then ensure that the profile
						// object keeps the setting (if the UserProfile
						// wasn't set up correctly, the default will be
						// basic user)
						if (UserUtilities.isSystemAdmin(user.getUsername(),
								ups_)) {
							user.setUserTypeId(UserProfile.USER_TYPE_SYS_ADMIN);
						}
						updateUsernames.add(un);
						update.add(user);
						LOG.debug("adding " + user.getUsername()
								+ " to update list");
					}
				}
			}
		}

		// if there are users in the deactivate list, double-check to make
		// sure the account is actually deactivated, and then add to the
		// deactivate list.
		for (UserProfile p : accountsToDeactivate_) {
			String un = p.getUsername();
			if (us_.doesUserExist(un)
					&& !UserUtilities.isUserDeactivated(un, ups_)) {
				LOG.debug("adding user \"" + un + "\" to deactivate list");
				deactivate.add(un);
			}
		}

		// execute the synchronization in Appian
		int updatedAccountsCount = executeAccounts(create, reactivate, deactivate, update, retry,
				titles, newAccountUsernames, us_, ups_);

		if (!newAccountUsernames.isEmpty()) {
			notifyServices(newAccountUsernames, sc_);
		}

		// add to the map that returns the number of accounts
		// created/updated/deactivated/reactivated to the UI or script
		int sizeRetriedCreated = ((Long) returnMap.get(USERS_CREATED)).intValue();
		returnMap.put(USERS_CREATED, new Long(newAccountUsernames.size()+ sizeRetriedCreated));
		
		String[] usernamesRetriedCreated = ((String[])returnMap.get(USERNAMES_CREATED)); 
		newAccountUsernames.addAll(Arrays.asList(usernamesRetriedCreated));
		returnMap.put(USERNAMES_CREATED, newAccountUsernames.toArray(usernamesRetriedCreated));
		
		int sizeRetriedDeactivated = ((Long) returnMap.get(USERS_DEACTIVATED)).intValue();
		returnMap.put(USERS_DEACTIVATED, new Long(deactivate.size()+ sizeRetriedDeactivated));
		
		String[] usernamesRetriedDeactivated = ((String[])returnMap.get(USERNAMES_DEACTIVATED)); 
		deactivate.addAll(Arrays.asList(usernamesRetriedDeactivated));
		returnMap.put(USERNAMES_DEACTIVATED, deactivate.toArray(usernamesRetriedDeactivated));
		
		int sizeRetriedReactivated = ((Long) returnMap.get(USERS_REACTIVATED)).intValue();
		returnMap.put(USERS_REACTIVATED, new Long(reactivate.size()+ sizeRetriedReactivated));
		
		String[] usernamesRetriedReactivated = ((String[])returnMap.get(USERNAMES_REACTIVATED)); 
		reactivate.addAll(Arrays.asList(usernamesRetriedReactivated));
		returnMap.put(USERNAMES_REACTIVATED, reactivate.toArray(usernamesRetriedReactivated));

		int sizeRetriedUpdated = ((Long) returnMap.get(USERS_UPDATED)).intValue();
		returnMap.put(USERS_UPDATED, new Long(updatedAccountsCount+ sizeRetriedUpdated));


		String[] usernamesRetriedUpdated = ((String[])returnMap.get(USERNAMES_UPDATED)); 
		updateUsernames.addAll(Arrays.asList(usernamesRetriedUpdated));
		returnMap.put(USERNAMES_UPDATED, updateUsernames.toArray(usernamesRetriedUpdated));

		return retry;
	}

	/**
	 * Execute the synchronization in Appian Personalization. This method
	 * create, update or deactivate user accounts.
	 * This method returns the number of accounts updated
	 * 
	 * @param create
	 * @param reactivate
	 * @param deactivate
	 * @param update
	 * @param retry
	 * @param titles
	 * @param newAccountUsernames
	 * @param us_
	 * @param ups_
	 * @throws DuplicateNameException
	 * @throws InvalidNameException
	 * @throws PrivilegeException
	 * @throws InvalidUserException
	 */
	private static int executeAccounts(final List<UserProfile> create,
			final List<String> reactivate, final List<String> deactivate,
			final List<UserProfile> update, List<UserProfile> retry,
			final List<String> titles, List<String> newAccountUsernames,
			UserService us_, UserProfileService ups_)
			throws DuplicateNameException, InvalidNameException,
			PrivilegeException, InvalidUserException {

		int updatedAccountsCounter = 0;
		
		if (!titles.isEmpty()) {
			LOG.debug("attempting to resolve " + titles.size() + " titles");
			resolveTitles(titles, us_);
		}

		// Titles in user profiles must be translated from their labels to their
		// IDs in order to be saved
		HashMap<String, Long> allUserRanks = getAllUserRanks(us_);

		if (!create.isEmpty()) {
			LOG.debug("attempting to create " + create.size() + " accounts");

			for (UserProfile tempProfile : create) {
				try {
					resolveTitleInProfile(tempProfile, allUserRanks);
					ups_.createUser(tempProfile);

					// add the valid new account username to the list of
					// accounts that need to be synch accross Appian engines
					newAccountUsernames.add(tempProfile.getUsername());
				} catch (InvalidSupervisorException e) {
					LOG.error(
							"Attempt to create user failed: Invalid Supervisor. Check Log -- USER IS:"
									+ tempProfile.getUsername(), e);
					// add the user to the list of retry because supervisor may
					// still need to be created from LDAP
					retry.add(tempProfile);
				} catch (Exception e) {
					LOG.error(
							"Attempt to create user failed. Check Log -- USER IS:"
									+ tempProfile.getUsername(), e);
				}
			}
		}

		if (!reactivate.isEmpty()) {
			LOG.debug("attempting to reactivate " + reactivate.size()
					+ " accounts");
			us_.reactivateUsers((String[]) reactivate
					.toArray(new String[reactivate.size()]));
		}

		if (!update.isEmpty()) {
			LOG.debug("attempting to update " + update.size() + " accounts");
			for (UserProfile tempProfile : update) {
				try {
					resolveTitleInProfile(tempProfile, allUserRanks);
					//check the supervisor
					String tempSupervisor = tempProfile.getSupervisorName();
					if (StringUtils.isEmpty(tempSupervisor)
							|| (us_.doesUserExist(tempSupervisor) && !UserUtilities
									.isUserDeactivated(tempSupervisor, ups_))) {
						ups_.updateUser(tempProfile);
						
						//increment the number of updated account
						updatedAccountsCounter ++;
					} else {
						LOG.info("User not updated: " + tempProfile.getUsername() 
								+ ". The supervisor of this user is not valid. Supervisor username: "
								+ tempSupervisor);
						retry.add(tempProfile);
					}
				} catch (InvalidSupervisorException e) {
					LOG.error(
							"Attempt to update user failed: Invalid Supervisor. Check Log -- USER IS:"
									+ tempProfile.getUsername(), e);
					// add the user to the list of retry because supervisor may
					// still need to be created from LDAP
					retry.add(tempProfile);
				} catch (Exception e) {
					LOG.error(
							"Unplanned Exception - Attempt to update user failed. Check Log -- USER IS:"
									+ tempProfile.getUsername(), e);
				}

			}
		}

		if (!deactivate.isEmpty()) {
			LOG.debug("attempting to deactivate " + deactivate.size()
					+ " accounts");
			try {
				us_.deactivateUsers((String[]) deactivate
						.toArray(new String[deactivate.size()]));
			} catch (Exception e) {
				// this should never happen - the list is checked for existence
				// when it's populated
				LOG.warn("tried to deactivate some invalid accounts - not a problem",e);
			}
		}
		
		return updatedAccountsCounter;
	}

	public static void resolveTitles(final List<String> titles_,
			final UserService us_) throws PrivilegeException {
		if (titles_ == null) {
			throw new NullPointerException();
		}
		if (titles_.isEmpty()) {
			throw new IllegalArgumentException();
		}

		// get the list of existing titles from AE
		ArrayList<UserRank> existingTitles = new ArrayList<UserRank>(
				Arrays.asList(us_.getRankList()));

		for (String title : titles_) {
			boolean exists = false;
			if (StringUtils.isNotEmpty(title)) {
				// create the title/rank if the rank doesn't exist in the system
				// AND if it doesn't exist in the list of existing titles/ranks.
				// on creation, add the title/rank to the list of existing ones.
				for (UserRank usrRank : existingTitles) {
					String rank = usrRank.getName();
					if (rank.equals(title)) {
						exists = true;
						break;
					}
				}

				if (!exists) {
					LOG.debug("title \"" + title
							+ "\" doesn't exist - creating...");
					UserRank rank = new UserRank();
					rank.setName(title);
					rank.setId(us_.createTitle(rank));
					existingTitles.add(rank);
					// adding the rank to the exsting-titles list prevents
					// double-addition of the rank and speeds up execution
				} else {
					LOG.debug("title \"" + title + "\" already exists");
				}
			}
		}
	}

	public static HashMap<String, Long> getAllUserRanks(UserService us) {
		HashMap<String, Long> ranks = new HashMap<String, Long>();

		UserRank[] rankList = us.getRankList();
		if (rankList != null) {
			for (int i = 0; i < rankList.length; i++) {
				ranks.put(rankList[i].getName(), rankList[i].getId());
			}
		}
		return ranks;
	}

	/**
	 * Update the ID of the title into the User Profile. This is essential when
	 * new titles are created as part of the synchronization.
	 * 
	 * @param profile
	 * @param allUserRanks
	 */
	public static void resolveTitleInProfile(UserProfile profile,
			HashMap<String, Long> allUserRanks) {

		// if the profile ID is not set and the profile contains a title
		if (StringUtils.isNotEmpty(profile.getTitleName())) {
			LOG.debug("User profile: " + profile.getUsername()
					+ " - Attempting to resolve the title: "
					+ profile.getTitleName());
			Long titleId = (Long) allUserRanks.get(profile.getTitleName());
			if (titleId != null) {
				profile.setTitleId(titleId);
				LOG.debug("User profile: " + profile.getUsername()
						+ " - the title " + profile.getTitleName()
						+ " has been resolved successfully");
			} else {
				LOG.debug("User profile: " + profile.getUsername()
						+ " - the title " + profile.getTitleName()
						+ " could not be resolved");
			}
		} else {
			LOG.debug("User profile: " + profile.getUsername()
					+ " - No title to resolve");
		}
	}

	/**
	 * Synchronize new user accounts accross all engines that must be notified
	 * of new users.
	 * 
	 * @param usernames_
	 * @param sc_
	 */
	public static void notifyServices(final List<String> usernames_,
			final ServiceContext sc_) {
		if (usernames_ == null) {
			throw new NullPointerException();
		}
		if (usernames_.isEmpty()) {
			throw new IllegalArgumentException();
		}

		AdministrationService pas = ServiceLocator
				.getPortalAdministrationService(sc_);
		ProcessDesignService pds = ServiceLocator.getProcessDesignService(sc_);
		ProcessAnalyticsService pras = ServiceLocator
				.getProcessAnalyticsService2(sc_);
		ContentService cs = ServiceLocator.getContentService(sc_);
		DiscussionMetadataCoreService dmcs = ServiceLocator
				.getDiscussionMetadataCoreService(sc_);

		LOG.debug("attempting to notify services of " + usernames_.size()
				+ " new account(s)");

		// notify all the services of new user accounts
		String[] uns = (String[]) usernames_.toArray(new String[usernames_
				.size()]);
		pas.notifyUsersCreation(uns);
		pras.notifyUsersCreation(uns);
		pds.notifyUsersCreation(uns);
		cs.notifyUsersCreation(uns);
		dmcs.notifyUsersCreation(uns);

		LOG.debug("notified services");
	}
}
