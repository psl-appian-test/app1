package com.appian.directory.syncwithusernames;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.appian.directory.syncwithusernames.service.SynchronizationService;
import com.appiancorp.plugin.directory.type.LdapSyncConfig;
import com.appiancorp.services.ServiceContext;
import com.appiancorp.services.ServiceContextFactory;
import com.appiancorp.suiteapi.common.Name;
import com.appiancorp.suiteapi.content.ContentService;
import com.appiancorp.suiteapi.personalization.UserProfileService;
import com.appiancorp.suiteapi.personalization.UserService;
import com.appiancorp.suiteapi.process.exceptions.SmartServiceException;
import com.appiancorp.suiteapi.process.framework.AppianSmartService;
import com.appiancorp.suiteapi.process.framework.Input;
import com.appiancorp.suiteapi.process.framework.Order;
import com.appiancorp.suiteapi.process.framework.Required;
import com.appiancorp.suiteapi.process.framework.SmartServiceContext;
import com.appiancorp.suiteapi.process.palette.ConnectivityServices;
import com.appiancorp.suiteapi.security.external.SecureCredentialsStore;

@ConnectivityServices
@Order({
	"scsExternalSystemKey", "usePerUserCredentials", "authenticationBaseDN", "authenticationType", "connectionUrl", "connectionTimeout",
	"connectionType", "connectionReferral", "connectionUsepool", "connectionKeystore", "synchUserFilter", "synchUserDeactivatedBaseDN",
	"synchUserDeactivatedFilter", "synchUserReactivate", "synchLowercaseUsername", "pageControlSupported", "pageControlPageSize",
	"authenticationUserPrefix", "authenticationUserSuffix", "userProfilePhoto", "userUsername", "userFirstName", "userMiddleName",
	"userLastName", "userDisplayName", "userEmail", "userPhoneHome", "userPhoneMobile", "userPhoneOffice", "userAddressCity",
	"userAddressCountry", "userAddressLine1", "userAddressLine2", "userAddressLine3", "userAddressPostalCode", "userAddressProvince",
	"userAddressState", "userSupervisorUsername", "userTitle", "userCustom1", "userCustom2", "userCustom3", "userCustom4", "userCustom5",
	"userCustom6", "userCustom7", "userCustom8", "userCustom9", "userCustom10", "result", "duration", "usersCreated", "usersUpdated",
	"usersDeactivated", "usersReactivated", "usersFailed", "usernamesCreated", "usernamesUpdated", "usernamesDeactivated", "usernamesReactivated"
})
public class ADUserSynchronization extends AppianSmartService {
	private static final Logger LOG = Logger.getLogger(ADUserSynchronization.class);

	private static final String PLUGIN_KEY = "adusersynchronizationwithusernames.LDAPUserProfileSynchronization";
	private static final String CRED_USERNAME = "username";
	private static final String CRED_PASSWORD = "password";
	
	private static final String USERS_CREATED = "usersCreated";
	private static final String USERS_DEACTIVATED = "usersDeactivated";
	private static final String USERS_REACTIVATED = "usersReactivated";
	private static final String USERS_UPDATED = "usersUpdated";
	private static final String USERS_FAILED = "usersFailed";
	private static final String USERNAMES_CREATED = "usernamesCreated";
	private static final String USERNAMES_DEACTIVATED = "usernamesDeactivated";
	private static final String USERNAMES_REACTIVATED = "usernamesReactivated";
	private static final String USERNAMES_UPDATED = "usernamesUpdated";
 
	private static final String NO_SCS_FIELD = "missing.scs.field";
	private static final String SCS_ERROR = "scs.error";
	private static final String SYNCHRONIZATION_SUCCESSFUL = "synch.success";

	private final SmartServiceContext smartServiceCtx;
	private final SecureCredentialsStore scs;
	private final ContentService cs;
	private final UserProfileService ups;
	private final UserService us;

	private LdapSyncConfig config = new LdapSyncConfig();
	private String result;
	private Long duration;
	private Long usersCreated;
	private Long usersUpdated;
	private Long usersDeactivated;
	private Long usersReactivated;
	private String[] usersFailed;
	private String[] usernamesCreated;
	private String[] usernamesUpdated;
    private String[] usernamesDeactivated;
    private String[] usernamesReactivated;

	public ADUserSynchronization(SmartServiceContext smartServiceCtx, SecureCredentialsStore scs, ContentService cs, UserProfileService ups, UserService us) {
		this.smartServiceCtx = smartServiceCtx;
		this.scs = scs;
		this.cs = cs;
		this.ups = ups;
		this.us = us;
	}

	@Override
	public void run() throws SmartServiceException {
		if (StringUtils.isNotEmpty(config.getScsExternalSystemKey())) {
			try {
				Map<String, String> credentials = config.getUsePerUserCredentials() ? scs.getUserSecuredValues(config.getScsExternalSystemKey()) : scs.getSystemSecuredValues(config.getScsExternalSystemKey());

				if (!credentials.containsKey(CRED_USERNAME)) {
					result = getMessageForCode(NO_SCS_FIELD, CRED_USERNAME, config.getScsExternalSystemKey());
					return;
				} else if (!credentials.containsKey(CRED_PASSWORD)) {
					result = getMessageForCode(NO_SCS_FIELD, CRED_PASSWORD, config.getScsExternalSystemKey());
					return;
				}

				config.setAuthenticationUserName(credentials.get(CRED_USERNAME));
				config.setAuthenticationUserPassword(credentials.get(CRED_PASSWORD));
			} catch (Exception e) {
				LOG.error("Unable to retrieve credentials from SCS", e);
				result = getMessageForCode(SCS_ERROR, e);
				return;
			}
		}

		LOG.info("Synchronizing user accounts... this may take a few minutes");
		
		SynchronizationService synchService = new SynchronizationService();

		try {
			ServiceContext sc_ = ServiceContextFactory.getServiceContext(smartServiceCtx.getUsername());
			long begin = System.currentTimeMillis();
			synchService.connect(config);
			synchService.initAttributes(config);
			Map<String,Object> m = synchService.synchronizeUsers(config, cs, ups, us, sc_);
			long end = System.currentTimeMillis();
			//set the smart service output Duration
			this.duration = new Long(end - begin);

			LOG.info("The synchronization task completed in " + duration + " milliseconds");

			//set the smart service outputs
			this.usersCreated = ((Long) m.get(USERS_CREATED));
			this.usersUpdated = ((Long) m.get(USERS_UPDATED));
			this.usersDeactivated = ((Long )m.get(USERS_DEACTIVATED));
			this.usersReactivated = ((Long) m.get(USERS_REACTIVATED));
			this.usersFailed = ((String []) m.get(USERS_FAILED));
			this.usernamesCreated = ((String[])m.get(USERNAMES_CREATED));
			this.usernamesDeactivated = ((String[])m.get(USERNAMES_DEACTIVATED)); 
			this.usernamesReactivated =  ((String[])m.get(USERNAMES_REACTIVATED));
			this.usernamesUpdated =  ((String[])m.get(USERNAMES_UPDATED));
			this.result = getMessageForCode(SYNCHRONIZATION_SUCCESSFUL);

		} catch(Exception e){
			LOG.error("Error synchronizing user accounts from LDAP", e);
			throw new SmartServiceException.Builder(getClass(),e).build();
		} finally {
			if (synchService != null) {
				synchService.closeConnection();
			}
		}
		
	}

	/**
	   * Gets the corresponding message from the bundle for a given return code
	   * 
	   * @param code
	   *          the code returned from the executeTask() method
	   * @param params
	   *          the parameter values to replace
	   * @return the plain-text message
	   */
	 protected String getMessageForCode(String code, Object... params) {
	   Locale locale = smartServiceCtx.getUserLocale() == null ? smartServiceCtx.getPrimaryLocale()
	     : smartServiceCtx.getUserLocale();
	 
	   try {
	     ResourceBundle bundle = ResourceBundle.getBundle(PLUGIN_KEY, locale);

	     return MessageFormat.format(bundle.getString(code), params);
	   } catch (Exception e) {
	     LOG.error("Error getting message for code " + code + " from bundle " + PLUGIN_KEY, e);
	     return "";
	   }
	 }

	@Input(required = Required.OPTIONAL)
	@Name("connectionKeystore")
	public void setConnectionKeystore(String val) {
		config.setConnectionKeystore(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="follow")
	@Name("connectionReferral")
	public void setConnectionReferral(String val) {
		config.setConnectionReferral(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="clear")
	@Name("connectionType")
	public void setConnectionType(String val) {
		config.setConnectionType(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="true")
	@Name("connectionUsepool")
	public void setConnectionUsepool(Boolean val) {
		config.setConnectionUsepool(val);
	}

	@Input(required = Required.ALWAYS,defaultValue="ldap://myLDAPServer:389")
	@Name("connectionUrl")
	public void setConnectionUrl(String val) {
		config.setConnectionUrl(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="2000")
	@Name("connectionTimeout")
	public void setConnectionTimeout(Long val) {
		config.setConnectionTimeout(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("scsExternalSystemKey")
	public void setScsExternalSystemKey(String val) {
		config.setScsExternalSystemKey(val);
	}

	@Input(required = Required.OPTIONAL, defaultValue="false")
	@Name("usePerUserCredentials")
	public void setUsePerUserCredentials(Boolean val) {
		config.setUsePerUserCredentials(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="ou=devusers,dc=mycompany,dc=com")
	@Name("authenticationBaseDN")
	public void setAuthenticationBaseDN(String val) {
		config.setAuthenticationBaseDN(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="simple")
	@Name("authenticationType")
	public void setAuthenticationType(String val) {
		config.setAuthenticationType(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("authenticationUserPrefix")
	public void setAuthenticationUserPrefix(String val) {
		config.setAuthenticationUserPrefix(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("authenticationUserSuffix")
	public void setAuthenticationUserSuffix(String val) {
		config.setAuthenticationUserSuffix(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="(objectClass=person)")
	@Name("synchUserFilter")
	public void setSynchUserFilter(String val) {
		config.setSynchUserFilter(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("synchUserDeactivatedBaseDN")
	public void setSynchUserDeactivatedBaseDN(String val) {
		config.setSynchUserDeactivatedBaseDN(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("synchUserDeactivatedFilter")
	public void setSynchUserDeactivatedFilter(String val) {
		config.setSynchUserDeactivatedFilter(val);
	}

	@Input(required = Required.OPTIONAL, defaultValue="true")
	@Name("synchUserReactivate")
	public void setSynchUserReactivate(Boolean val) {
		config.setSynchUserReactivate(val);
	}
	
	@Input(required = Required.OPTIONAL, defaultValue="true")
	@Name("synchLowercaseUsername")
	public void setSynchLowercaseUsername(Boolean val) {
		config.setSynchLowercaseUsername(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressCity")
	public void setUserAddressCity(String val) {
		config.setUserAddressCity(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressCountry")
	public void setUserAddressCountry(String val) {
		config.setUserAddressCountry(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressLine1")
	public void setUserAddressLine1(String val) {
		config.setUserAddressLine1(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressLine2")
	public void setUserAddressLine2(String val) {
		config.setUserAddressLine2(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressLine3")
	public void setUserAddressLine3(String val) {
		config.setUserAddressLine3(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressPostalCode")
	public void setUserAddressPostalCode(String val) {
		config.setUserAddressPostalCode(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressProvince")
	public void setUserAddressProvince(String val) {
		config.setUserAddressProvince(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userAddressState")
	public void setUserAddressState(String val) {
		config.setUserAddressState(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom1")
	public void setUserCustom1(String val) {
		config.setUserCustom1(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom2")
	public void setUserCustom2(String val) {
		config.setUserCustom2(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom3")
	public void setUserCustom3(String val) {
		config.setUserCustom3(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom4")
	public void setUserCustom4(String val) {
		config.setUserCustom4(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom5")
	public void setUserCustom5(String val) {
		config.setUserCustom5(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom6")
	public void setUserCustom6(String val) {
		config.setUserCustom6(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom7")
	public void setUserCustom7(String val) {
		config.setUserCustom7(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom8")
	public void setUserCustom8(String val) {
		config.setUserCustom8(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom9")
	public void setUserCustom9(String val) {
		config.setUserCustom9(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userCustom10")
	public void setUserCustom10(String val) {
		config.setUserCustom10(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="mail")
	@Name("userEmail")
	public void setUserEmail(String val) {
		config.setUserEmail(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userDisplayName")
	public void setUserDisplayName(String val) {
		config.setUserDisplayName(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="givenName")
	@Name("userFirstName")
	public void setUserFirstName(String val) {
		config.setUserFirstName(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="sn")
	@Name("userLastName")
	public void setUserLastName(String val) {
		config.setUserLastName(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userMiddleName")
	public void setUserMiddleName(String val) {
		config.setUserMiddleName(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userPhoneHome")
	public void setUserPhoneHome(String val) {
		config.setUserPhoneHome(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userPhoneMobile")
	public void setUserPhoneMobile(String val) {
		config.setUserPhoneMobile(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userPhoneOffice")
	public void setUserPhoneOffice(String val) {
		config.setUserPhoneOffice(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userSupervisorUsername")
	public void setUserSupervisorUsername(String val) {
		config.setUserSupervisorUsername(val);
	}

	@Input(required = Required.OPTIONAL)
	@Name("userTitle")
	public void setUserTitle(String val) {
		config.setUserTitle(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="sAMAccountName")
	@Name("userUsername")
	public void setUserUsername(String val) {
		config.setUserUsername(val);
	}

	@Input(required = Required.OPTIONAL, defaultValue="thumbnailPhoto")
	@Name("userProfilePhoto")
	public void setUserProfilePhoto(String val) {
		config.setUserProfilePhoto(val);
	}

	@Input(required = Required.ALWAYS, defaultValue="true")
	@Name("pageControlSupported")
	public void setPageControlSupported(Boolean val) {
		config.setPageControlSupported(val);
	}
	
	@Input(required = Required.OPTIONAL, defaultValue="1000")
	@Name("pageControlPageSize")
	public void setPageControlPageSize(Long val) {
		config.setPageControlPageSize(val);
	}

	@Name("result")
	public String getResult() {
		return result;
	}

	@Name("duration")
	public Long getDuration() {
		return duration;
	}

	@Name("usersCreated")
	public Long getUsersCreated() {
		return usersCreated;
	}

	@Name("usersUpdated")
	public Long getUsersUpdated() {
		return usersUpdated;
	}

	@Name("usersDeactivated")
	public Long getUsersDeactivated() {
		return usersDeactivated;
	}

	@Name("usersReactivated")
	public Long getUsersReactivated() {
		return usersReactivated;
	}
	
	@Name("usersFailed")
	public String[] getUsersFailed() {
		return usersFailed;
	}

	@Name("usernamesCreated")
	public String[] getUsernamesCreated() {
		return usernamesCreated;
	}
	
	@Name("usernamesUpdated")
	public String[] getUsernamesUpdated() {
		return usernamesUpdated;
	}
	
	@Name("usernamesDeactivated")
	public String[] getUsernamesDeactivated() {
		return usernamesDeactivated;
	}

	@Name("usernamesReactivated")
	public String[] getUsernamesReactivated() {
		return usernamesReactivated;
	}
}
